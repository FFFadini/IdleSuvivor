@echo off
echo A instalar dependencias...
pip install pygame pyinstaller
echo.
echo A gerar o executavel do jogo...
pyinstaller --onefile --noconsole --name="IdleSurvivor" --add-data "assets\VT323-Regular.ttf;assets" --add-data "assets\OFL.txt;assets" main.py
echo.
echo Concluido com sucesso! O executavel encontra-se na pasta 'dist'.
pause