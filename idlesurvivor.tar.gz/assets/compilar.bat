@echo off
echo A instalar dependencias...
pip install pygame pyinstaller
echo.
echo A gerar o executavel do jogo...
pyinstaller --onefile --noconsole --name="IdleSurvivor" --add-data "assets\8-BIT WONDER.TTF;assets" main.py
echo.
echo Concluido com sucesso! O executavel encontra-se na pasta 'dist'.
pause