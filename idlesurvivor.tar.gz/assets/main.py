import asyncio
import json
import pygame
import math
import random
import os
import sys

if sys.platform != "emscripten":
    import sqlite3

# Inicialização do Pygame
pygame.init()
LARGURA, ALTURA = 800, 600
TELA = pygame.display.set_mode((LARGURA, ALTURA))
if sys.platform == "emscripten":
    import platform
    doc = platform.window.document

    # Viewport correto para celular (o template padrão do pygbag omite a largura)
    meta_viewport = doc.querySelector('meta[name="viewport"]')
    if meta_viewport:
        meta_viewport.setAttribute(
            "content", "width=device-width, height=device-height, initial-scale=1.0, viewport-fit=cover")

    # Canvas 4:3 centralizado, sem esticar. Os dois pares width/height garantem o
    # layout correto mesmo em navegadores sem suporte a 'dvh' (o último válido vence).
    estilo_tela = doc.createElement("style")
    estilo_tela.textContent = """
        html, body { margin: 0; height: 100%; overflow: hidden; }
        body { display: flex; align-items: center; justify-content: center; }
        canvas#canvas {
            position: static !important;
            margin: 0 !important;
            width: min(100vw, calc(100vh * 4 / 3)) !important;
            height: min(100vh, calc(100vw * 3 / 4)) !important;
            width: min(100vw, calc(100dvh * 4 / 3)) !important;
            height: min(100dvh, calc(100vw * 3 / 4)) !important;
            image-rendering: auto;
            touch-action: none;
        }
    """
    doc.head.appendChild(estilo_tela)
    platform.window.canvas.style.transform = "none"

    estilo_fundo = doc.body.style
    estilo_fundo.background = "#10091b"
    estilo_fundo.backgroundImage = 'url("game-background.svg")'
    estilo_fundo.backgroundSize = "cover"
    estilo_fundo.backgroundPosition = "center"
    estilo_fundo.backgroundRepeat = "no-repeat"
pygame.display.set_caption("Idle Survivor")
DIRETORIO_BASE = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
CAMINHO_FONTE = os.path.join(DIRETORIO_BASE, "assets", "VT323-Regular.ttf")
FONTE = pygame.font.Font(CAMINHO_FONTE, 20)
FONTE_TITULO = pygame.font.Font(CAMINHO_FONTE, 36)
FONTE_TITULO.set_bold(True)
FONTE_PEQ = pygame.font.Font(CAMINHO_FONTE, 16)
FONTE_PEQ.set_bold(True)
FONTE_NUM = pygame.font.Font(CAMINHO_FONTE, 18)
FONTE_NUM.set_bold(True)
FPS = 60

# ==========================================
# CONFIGURAÇÃO DE FASES E HABILIDADES
# ==========================================
TOTAL_FASES = 20

def meta_abates(fase):
    """Quantos inimigos comuns precisam morrer antes do boss da fase."""
    return 6 + fase * 2

# Cooldowns em SEGUNDOS (ajuste aqui se quiser outro tempo)
HABILIDADES_CFG = {
    "missil": {"nome": "MÍSSEL", "cooldown": 35, "tecla": "Q", "custo": 3, "cor": (255, 140, 60),
               "desc": "Dano 50 em área ao acertar"},
    "laser": {"nome": "LASER CONSTANTE", "cooldown": 20, "tecla": "W", "custo": 5, "cor": (80, 220, 255),
              "desc": "20 de dano por segundo durante 5s"},
    "cura": {"nome": "RECUPERAÇÃO DE VIDA", "cooldown": 50, "tecla": "E", "custo": 2, "cor": (90, 255, 140),
             "desc": "Recupera 20 de vida (+10 por nível)"},
}
# Paleta de cada mundo (4 fases por mundo): céu topo/base, chão topo/base, neblina
TEMAS_MUNDO = [
    ((6, 6, 24), (62, 30, 74), (30, 70, 42), (6, 18, 14), (90, 150, 140)),      # 1-4  floresta noturna
    ((22, 8, 40), (86, 30, 80), (60, 38, 78), (16, 10, 28), (150, 90, 170)),    # 5-8  pântano arcano
    ((6, 22, 40), (30, 80, 110), (40, 80, 96), (8, 24, 34), (110, 190, 220)),   # 9-12 geleira
    ((30, 8, 8), (110, 36, 20), (84, 40, 28), (24, 10, 8), (210, 110, 70)),     # 13-16 vulcão
    ((2, 0, 14), (50, 10, 70), (36, 20, 64), (8, 4, 20), (170, 80, 220)),       # 17-20 vazio cósmico
]
MISSIL_DANO = 50
LASER_DANO_POR_SEG = 20
LASER_DURACAO = 5          # segundos
CURA_BASE = 20
CURA_POR_NIVEL = 10

# Layout vertical: o horizonte é onde começa o chão; PE_Y é a linha onde
# jogador e inimigos apoiam os pés (dentro da faixa de chão).
HORIZONTE = ALTURA - 100
PE_Y = ALTURA - 52

# ==========================================
# AUXILIARES VISUAIS (apenas desenho)
# ==========================================
_CACHE_BRILHO = {}
_CACHE_SOMBRA = {}

def gradiente_vertical(largura, altura, topo, base):
    surf = pygame.Surface((largura, altura))
    for y in range(altura):
        t = y / max(1, altura - 1)
        cor = tuple(int(topo[i] + (base[i] - topo[i]) * t) for i in range(3))
        pygame.draw.line(surf, cor, (0, y), (largura, y))
    return surf

def brilho(tela, cor, centro, raio, intensidade=0.9):
    """Halo de luz aditivo (cacheado; intensidade quantizada para o cache não crescer)."""
    intensidade = round(intensidade * 20) / 20
    chave = (cor, raio, intensidade)
    surf = _CACHE_BRILHO.get(chave)
    if surf is None:
        surf = pygame.Surface((raio * 2, raio * 2))
        for r in range(raio, 0, -2):
            f = intensidade * (1 - r / raio) ** 2
            pygame.draw.circle(surf, (int(cor[0] * f), int(cor[1] * f), int(cor[2] * f)), (raio, raio), r)
        _CACHE_BRILHO[chave] = surf
    tela.blit(surf, (int(centro[0] - raio), int(centro[1] - raio)), special_flags=pygame.BLEND_RGB_ADD)

def sombra_chao(tela, cx, pes_y, largura, alpha=110):
    """Elipse escura centrada nos pés da entidade."""
    largura = max(6, int(largura))
    chave = (largura, alpha)
    surf = _CACHE_SOMBRA.get(chave)
    if surf is None:
        surf = pygame.Surface((largura, 12), pygame.SRCALPHA)
        pygame.draw.ellipse(surf, (0, 0, 0, alpha), (0, 0, largura, 12))
        pygame.draw.ellipse(surf, (0, 0, 0, alpha // 2), (largura // 5, 2, largura * 3 // 5, 8))
        _CACHE_SOMBRA[chave] = surf
    tela.blit(surf, (int(cx - largura / 2), int(pes_y - 6)))

_CACHE_PAINEL = {}
_CACHE_VEU = {}

def painel(tela, rect, cor=(10, 10, 25), alpha=170, borda=(90, 90, 150), raio=10):
    """Painel translúcido (cacheado: criar Surface SRCALPHA todo frame pesa no navegador)."""
    x, y, w, h = rect
    chave = (w, h, cor, alpha, borda, raio)
    surf = _CACHE_PAINEL.get(chave)
    if surf is None:
        surf = pygame.Surface((w, h), pygame.SRCALPHA)
        pygame.draw.rect(surf, (*cor, alpha), (0, 0, w, h), border_radius=raio)
        pygame.draw.rect(surf, (*borda, 255), (0, 0, w, h), 2, border_radius=raio)
        _CACHE_PAINEL[chave] = surf
    tela.blit(surf, (x, y))

def barra(tela, x, y, w, h, fracao, cor, fundo=(50, 15, 15), borda=(0, 0, 0)):
    fracao = max(0, min(1, fracao))
    pygame.draw.rect(tela, fundo, (x, y, w, h), border_radius=3)
    if fracao > 0:
        pygame.draw.rect(tela, cor, (x, y, max(2, int(w * fracao)), h), border_radius=3)
        # reflexo no topo da barra
        clara = tuple(min(255, c + 70) for c in cor)
        pygame.draw.rect(tela, clara, (x + 1, y + 1, max(1, int(w * fracao) - 2), max(1, h // 3)), border_radius=2)
    pygame.draw.rect(tela, borda, (x, y, w, h), 1, border_radius=3)

def texto_sombra(tela, fonte, texto, cor, pos, centro_x=False):
    sombra = fonte.render(texto, True, (0, 0, 0))
    principal = fonte.render(texto, True, cor)
    x, y = pos
    if centro_x:
        x = LARGURA // 2 - principal.get_width() // 2
    tela.blit(sombra, (x + 2, y + 2))
    tela.blit(principal, (x, y))

def criar_vinheta():
    surf = pygame.Surface((LARGURA, ALTURA), pygame.SRCALPHA)
    passos = 70
    for i in range(passos):
        a = int(140 * (1 - i / passos) ** 2)
        pygame.draw.rect(surf, (0, 0, 0, a), (i, i, LARGURA - 2 * i, ALTURA - 2 * i), 1)
    return surf

def botao(tela, rect, texto, mouse_pos, cor=(255, 215, 0), fonte=None):
    """Botão clicável com efeito hover. Retorna True se o mouse está sobre ele."""
    fonte = fonte or FONTE
    sobre = rect.collidepoint(mouse_pos)
    fundo = (50, 45, 100) if sobre else (20, 20, 50)
    borda = cor if sobre else tuple(c // 2 for c in cor)
    painel(tela, tuple(rect), cor=fundo, alpha=230, borda=borda)
    txt = fonte.render(texto, True, cor if sobre else (220, 220, 235))
    tela.blit(txt, txt.get_rect(center=rect.center))
    return sobre

def desenhar_moeda_especial(tela, cx, cy, r):
    """Moeda especial (cristal roxo) dropada pelos bosses."""
    brilho(tela, (190, 90, 255), (cx, cy), r * 2, 0.55)
    pts = [(cx, cy - r - 2), (cx + r, cy), (cx, cy + r + 2), (cx - r, cy)]
    pygame.draw.polygon(tela, (110, 40, 180), pts)
    pygame.draw.polygon(tela, (200, 130, 255), [(cx, cy - r + 1), (cx + r - 3, cy), (cx, cy + r - 1), (cx - r + 3, cy)])
    pygame.draw.polygon(tela, (245, 220, 255), [(cx, cy - r + 1), (cx - r + 3, cy), (cx, cy - 1)])
    pygame.draw.polygon(tela, (255, 255, 255), pts, 1)

def desenhar_botao_habilidade(tela, rect, hab, mouse_pos):
    """Botão de skill no HUD com tecla, recarga e estado bloqueado/ativo. Retorna True se há hover."""
    cfg = hab.cfg
    sobre = rect.collidepoint(mouse_pos)
    cor = cfg["cor"]
    if not hab.desbloqueada:
        painel(tela, tuple(rect), cor=(15, 15, 25), alpha=190, borda=(70, 70, 90))
        txt = FONTE_PEQ.render(f"[{cfg['tecla']}] BLOQ.", True, (110, 110, 130))
        tela.blit(txt, txt.get_rect(center=rect.center))
        return sobre
    pronta = hab.pronta
    ativa = hab.ativa > 0
    painel(tela, tuple(rect), cor=(40, 40, 85) if sobre else (15, 15, 40), alpha=230,
           borda=(255, 255, 255) if (sobre and pronta) else (cor if (pronta or ativa) else (80, 80, 100)))
    if pronta or ativa:
        brilho(tela, cor, rect.center, 40, 0.18 + (0.12 * math.sin(pygame.time.get_ticks() * 0.01) if pronta else 0.25))
    elif hab.timer > 0:
        # recarga: véu escuro que vai descendo
        falta = 1 - hab.fracao_recarga
        dim = (rect.w - 4, int((rect.h - 4) * falta))
        veu = _CACHE_VEU.get(dim)
        if veu is None:
            veu = pygame.Surface(dim, pygame.SRCALPHA)
            veu.fill((0, 0, 0, 150))
            _CACHE_VEU[dim] = veu
        tela.blit(veu, (rect.x + 2, rect.y + 2))
    nome = {"missil": "MÍSSEL", "laser": "LASER", "cura": "CURA"}[hab.chave]
    t1 = FONTE_PEQ.render(f"[{cfg['tecla']}] {nome}", True, cor if (pronta or ativa) else (150, 150, 170))
    tela.blit(t1, (rect.x + 6, rect.y + 6))
    if ativa:
        t2 = FONTE_PEQ.render(f"ATIVO {hab.ativa / FPS:.1f}s", True, (200, 245, 255))
    elif hab.timer > 0:
        t2 = FONTE_PEQ.render(f"{hab.timer / FPS:.0f}s", True, (220, 220, 235))
    else:
        t2 = FONTE_PEQ.render("PRONTO", True, (210, 255, 210))
    tela.blit(t2, (rect.x + 6, rect.y + 26))
    return sobre

# Áreas clicáveis da interface
BOTAO_LOJA = pygame.Rect(LARGURA - 140, 10, 130, 40)     # no HUD durante a batalha
BOTAO_VOLTAR = pygame.Rect(LARGURA // 2 - 100, 520, 200, 44)  # dentro da loja
BOTAO_LIMPAR_SAVE = pygame.Rect(90, 520, 190, 44)
BOTAO_CONFIRMAR_LIMPEZA = pygame.Rect(LARGURA // 2 - 145, 340, 130, 46)
BOTAO_CANCELAR_LIMPEZA = pygame.Rect(LARGURA // 2 + 15, 340, 130, 46)
BOTAO_RESTART = pygame.Rect(LARGURA // 2 - 100, 375, 200, 46)
BOTAO_CONTINUAR = pygame.Rect(LARGURA // 2 - 110, 400, 220, 46)  # fase completa / vitória
RECT_ITENS = [pygame.Rect(100, yy, 600, 76) for yy in (140, 230, 320)]
TAB_MELHORIAS = pygame.Rect(100, 100, 296, 30)
TAB_HABILIDADES = pygame.Rect(404, 100, 296, 30)
ORDEM_SKILLS = ("missil", "laser", "cura")
RECT_SKILLS_HUD = {chave: pygame.Rect(404 + i * 82, 10, 76, 46) for i, chave in enumerate(ORDEM_SKILLS)}
TECLAS_SKILLS = {pygame.K_q: "missil", pygame.K_w: "laser", pygame.K_e: "cura"}

def desenhar_loja(tela, jogador, aba, mouse_pos):
    """Desenha a aba atual da loja e retorna se o cursor está sobre uma área interativa."""
    tela.blit(FUNDO_LOJA, (0, 0))
    painel(tela, (55, 20, 690, 560), cor=(10, 10, 30), alpha=190, borda=(90, 90, 150))
    texto_sombra(tela, FONTE_TITULO, "LOJA", (255, 215, 0), (0, 34), centro_x=True)

    ouro_txt = FONTE.render(f"OURO: {jogador.dinheiro}", True, (255, 255, 255))
    tela.blit(ouro_txt, ouro_txt.get_rect(center=(LARGURA // 2, 83)))
    desenhar_moeda_especial(tela, 510, 83, 8)
    moedas_txt = FONTE.render(str(jogador.moedas), True, (230, 190, 255))
    tela.blit(moedas_txt, (526, 73))

    sobre_clicavel = False
    for rect, nome, valor in (
        (TAB_MELHORIAS, "MELHORIAS", "MELHORIAS"),
        (TAB_HABILIDADES, "HABILIDADES", "HABILIDADES"),
    ):
        sobre = rect.collidepoint(mouse_pos)
        selecionada = aba == valor
        cor = (255, 215, 0) if selecionada else (130, 140, 180)
        painel(tela, tuple(rect), cor=(45, 40, 75) if selecionada else (15, 15, 35),
               alpha=235, borda=cor if (selecionada or sobre) else (65, 65, 100))
        label = FONTE_PEQ.render(nome, True, cor if (selecionada or sobre) else (190, 190, 210))
        tela.blit(label, label.get_rect(center=rect.center))
        sobre_clicavel = sobre_clicavel or sobre

    if aba == "MELHORIAS":
        itens = (
            ("ATAQUE", jogador.nivel_ataque, (255, 100, 100)),
            ("VELOCIDADE DE ATAQUE", jogador.nivel_vel_ataque, (100, 255, 100)),
            ("VIDA MÁXIMA", jogador.nivel_vida, (100, 150, 255)),
        )
        for (nome, nivel, cor), rect in zip(itens, RECT_ITENS):
            custo = nivel * 50
            pode = jogador.dinheiro >= custo
            sobre = rect.collidepoint(mouse_pos)
            sobre_clicavel = sobre_clicavel or sobre
            painel(tela, tuple(rect), cor=(35, 35, 80) if sobre else (15, 15, 40),
                   alpha=225 if sobre else 190,
                   borda=(255, 255, 255) if (sobre and pode) else (cor if pode else (80, 80, 100)))
            pygame.draw.rect(tela, cor, (rect.x + 18, rect.y + 17, 6, 42))
            tela.blit(FONTE.render(nome, True, cor), (rect.x + 38, rect.y + 8))
            detalhe = FONTE_PEQ.render(f"NIVEL {nivel}   |   CUSTO {custo} OURO", True, (210, 210, 235))
            tela.blit(detalhe, (rect.x + 38, rect.y + 42))
            botao_rect = pygame.Rect(rect.right - 158, rect.y + 15, 140, 46)
            cor_botao = cor if pode else (80, 80, 100)
            pygame.draw.rect(tela, (25, 25, 55), botao_rect)
            pygame.draw.rect(tela, cor_botao, botao_rect, 2)
            acao = FONTE_PEQ.render("COMPRAR" if pode else "SEM OURO", True, cor_botao)
            tela.blit(acao, acao.get_rect(center=botao_rect.center))

        tiros = FPS / jogador.cooldown_ataque
        stats = f"Dano: {jogador.ataque_base}   |   Tiros/s: {tiros:.1f}   |   Vida máx: {jogador.vida_max}"
        stats_txt = FONTE.render(stats, True, (210, 210, 235))
        tela.blit(stats_txt, stats_txt.get_rect(center=(LARGURA // 2, 468)))
    else:
        for chave, rect in zip(ORDEM_SKILLS, RECT_ITENS):
            hab = jogador.habilidades[chave]
            custo = custo_habilidade(jogador, chave)
            pode = custo is not None and jogador.moedas >= custo
            sobre = rect.collidepoint(mouse_pos)
            sobre_clicavel = sobre_clicavel or sobre
            cor = hab.cfg["cor"]
            painel(tela, tuple(rect), cor=(35, 35, 80) if sobre else (15, 15, 40),
                   alpha=225 if sobre else 190,
                   borda=(255, 255, 255) if (sobre and pode) else (cor if pode else (80, 80, 100)))
            pygame.draw.rect(tela, cor, (rect.x + 18, rect.y + 17, 6, 42))
            tela.blit(FONTE.render(hab.cfg["nome"], True, cor), (rect.x + 38, rect.y + 7))
            descricao = FONTE_PEQ.render(hab.cfg["desc"], True, (210, 210, 235))
            tela.blit(descricao, (rect.x + 38, rect.y + 31))
            nivel = f"NÍVEL {hab.nivel}" if hab.desbloqueada else "BLOQUEADA"
            detalhes = nivel if custo is None else f"{nivel}   |   CUSTO {custo} CRISTAIS"
            detalhe = FONTE_PEQ.render(detalhes, True, (210, 210, 235))
            tela.blit(detalhe, (rect.x + 38, rect.y + 49))

            botao_rect = pygame.Rect(rect.right - 158, rect.y + 15, 140, 46)
            cor_botao = cor if pode else (80, 80, 100)
            pygame.draw.rect(tela, (25, 25, 55), botao_rect)
            pygame.draw.rect(tela, cor_botao, botao_rect, 2)
            acao = "MÁXIMO" if custo is None else ("COMPRAR" if pode else "SEM CRISTAIS")
            label = FONTE_PEQ.render(acao, True, cor_botao)
            tela.blit(label, label.get_rect(center=botao_rect.center))

        ajuda = FONTE_PEQ.render("MÍSSIL E LASER SÃO DESBLOQUEIOS ÚNICOS; A CURA PODE SUBIR DE NÍVEL",
                                 True, (180, 180, 205))
        tela.blit(ajuda, ajuda.get_rect(center=(LARGURA // 2, 468)))

    if botao(tela, BOTAO_LIMPAR_SAVE, "APAGAR SAVE", mouse_pos, cor=(255, 110, 110), fonte=FONTE_PEQ):
        sobre_clicavel = True
    if botao(tela, BOTAO_VOLTAR, "Voltar à Batalha", mouse_pos):
        sobre_clicavel = True
    return sobre_clicavel

def desenhar_confirmacao_limpeza(tela, mouse_pos):
    """Mostra confirmação explícita antes de apagar o progresso salvo."""
    tela.blit(OVERLAY_CONFIRMACAO, (0, 0))
    painel(tela, (170, 220, 460, 200), cor=(28, 10, 24), alpha=250, borda=(255, 100, 110), raio=14)
    texto_sombra(tela, FONTE_TITULO, "APAGAR TODO O SAVE?", (255, 120, 130), (0, 245), centro_x=True)
    texto_sombra(tela, FONTE, "Seu progresso e melhorias serão reiniciados.", (245, 225, 230),
                 (0, 290), centro_x=True)
    texto_sombra(tela, FONTE_PEQ, "Esta ação não pode ser desfeita.", (220, 170, 180),
                 (0, 318), centro_x=True)
    sobre_confirmar = botao(tela, BOTAO_CONFIRMAR_LIMPEZA, "APAGAR", mouse_pos, cor=(255, 100, 110),
                            fonte=FONTE_PEQ)
    sobre_cancelar = botao(tela, BOTAO_CANCELAR_LIMPEZA, "CANCELAR", mouse_pos, cor=(150, 210, 255),
                           fonte=FONTE_PEQ)
    return sobre_confirmar or sobre_cancelar

def desenhar_resultado(tela, fase, moedas_ganhas, vitoria, mouse_pos):
    """Apresenta o encerramento de fase, ou a vitória definitiva da campanha."""
    tela.blit(FUNDO_LOJA, (0, 0))
    for i in range(34):
        x = (i * 137 + pygame.time.get_ticks() // (8 + i % 5)) % LARGURA
        y = (i * 71 + 23) % ALTURA
        pygame.draw.circle(tela, (100, 80, 150), (x, y), 1 + i % 2)

    cor = (255, 220, 100) if vitoria else (150, 255, 190)
    painel(tela, (130, 125, 540, 350), cor=(12, 15, 35), alpha=225, borda=cor, raio=14)
    titulo = "VITÓRIA!" if vitoria else f"FASE {fase} COMPLETA!"
    texto_sombra(tela, FONTE_TITULO, titulo, cor, (0, 158), centro_x=True)
    boss_nome = BOSSES[fase - 1][0]
    texto_sombra(tela, FONTE, f"BOSS DERROTADO: {boss_nome}", (235, 225, 255), (0, 225), centro_x=True)
    if vitoria:
        texto_sombra(tela, FONTE, "Você salvou todos os mundos!", (255, 255, 255), (0, 275), centro_x=True)
        texto_sombra(tela, FONTE_PEQ, "A campanha foi concluída. Você pode enfrentar o boss final novamente.",
                     (200, 200, 225), (0, 312), centro_x=True)
        texto_botao = "REJOGAR FASE FINAL"
    else:
        texto_sombra(tela, FONTE, f"+{moedas_ganhas} cristal(is) especial(is)", (220, 170, 255),
                     (0, 275), centro_x=True)
        texto_sombra(tela, FONTE_PEQ, f"Próximo desafio: fase {fase + 1}/{TOTAL_FASES}",
                     (200, 200, 225), (0, 312), centro_x=True)
        texto_botao = "CONTINUAR"
    return botao(tela, BOTAO_CONTINUAR, texto_botao, mouse_pos, cor=cor)

def comprar(jogador, indice):
    """0 = Ataque, 1 = Vel. Ataque, 2 = Vida. Retorna True se a compra foi feita."""
    niveis = (jogador.nivel_ataque, jogador.nivel_vel_ataque, jogador.nivel_vida)
    custo = niveis[indice] * 50
    if jogador.dinheiro < custo:
        return False
    jogador.dinheiro -= custo
    if indice == 0:
        jogador.nivel_ataque += 1
    elif indice == 1:
        jogador.nivel_vel_ataque += 1
    else:
        jogador.nivel_vida += 1
    jogador.atualizar_status()
    return True

def custo_habilidade(jogador, chave):
    """Moedas para desbloquear a skill (nível 0) ou, no caso da cura, subir de nível."""
    hab = jogador.habilidades[chave]
    if not hab.desbloqueada:
        return hab.cfg["custo"]
    if chave == "cura":
        return 2 * hab.nivel
    return None  # míssil e laser não têm upgrade

def comprar_habilidade(jogador, chave):
    custo = custo_habilidade(jogador, chave)
    if custo is None or jogador.moedas < custo:
        return False
    jogador.moedas -= custo
    jogador.habilidades[chave].nivel += 1
    return True

def cura_atual(jogador):
    nivel = max(1, jogador.habilidades["cura"].nivel)
    return CURA_BASE + CURA_POR_NIVEL * (nivel - 1)

def usar_habilidade(jogador, chave, inimigos, misseis, particulas, textos):
    """Aciona a skill se estiver pronta e houver motivo para usá-la. Retorna True se foi usada."""
    hab = jogador.habilidades[chave]
    if not hab.pronta:
        return False
    if chave == "missil":
        if not inimigos:
            return False
        misseis.append(Missil(jogador.x + 44, jogador.y + 20))
    elif chave == "laser":
        if not inimigos:
            return False
        hab.ativa = LASER_DURACAO * FPS
    elif chave == "cura":
        if jogador.vida >= jogador.vida_max:
            return False
        curado = min(cura_atual(jogador), jogador.vida_max - jogador.vida)
        jogador._vida += curado
        textos.append(TextoFlutuante(f"+{curado} HP", (110, 255, 150), jogador.x + 20, jogador.y - 34))
        for _ in range(14):
            particulas.append(Particula(jogador.x + 20, jogador.y + 20, (110, 255, 150),
                                        vx=random.uniform(-1.5, 1.5), vy=random.uniform(-3, -0.5), vida=random.randint(20, 34), tam=3))
    hab.usar()
    return True

def reiniciar_partida(jogador, inimigos, projetis, projetis_boss, particulas, textos, misseis=None):
    jogador._vida = jogador.vida_max
    jogador.vivo = True
    jogador.timer_ataque = 0
    jogador.recuo = 0
    for hab in jogador.habilidades.values():
        hab.zerar()
    inimigos.clear()
    projetis.clear()
    projetis_boss.clear()
    particulas.clear()
    textos.clear()
    if misseis is not None:
        misseis.clear()

FUNDO_LOJA = gradiente_vertical(LARGURA, ALTURA, (28, 22, 60), (12, 12, 28))
FUNDO_GAMEOVER = gradiente_vertical(LARGURA, ALTURA, (120, 10, 10), (30, 0, 0))
VINHETA = criar_vinheta()
FLASH_DANO = pygame.Surface((LARGURA, ALTURA))
FLASH_DANO.fill((255, 30, 30))
OVERLAY_CONFIRMACAO = pygame.Surface((LARGURA, ALTURA), pygame.SRCALPHA)
OVERLAY_CONFIRMACAO.fill((0, 0, 0, 185))
BUFFER_TREMOR = pygame.Surface((LARGURA, ALTURA))

# ==========================================
# PERSISTÊNCIA DE DADOS (BANCO DE DADOS)
# ==========================================
# No navegador o localStorage é compartilhado por todo o domínio (github.io/usuario),
# então a chave precisa ser exclusiva deste jogo.
CHAVE_SAVE_WEB = "idle_survivor_save_v1"
def inicializar_db():
    if sys.platform == "emscripten":
        import platform
        return platform.window.localStorage

    conn = sqlite3.connect("save_idle.db")
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS jogador (
            nome TEXT PRIMARY KEY,
            dinheiro INTEGER,
            nivel_ataque INTEGER,
            nivel_vel_ataque INTEGER,
            nivel_vida INTEGER,
            abates INTEGER
        )
    ''')
    # Migração: saves antigos ganham as colunas novas sem perder progresso
    existentes = {linha[1] for linha in cursor.execute("PRAGMA table_info(jogador)")}
    for coluna in ("fase_concluida", "moedas", "skill_missil", "skill_laser", "nivel_cura"):
        if coluna not in existentes:
            cursor.execute(f"ALTER TABLE jogador ADD COLUMN {coluna} INTEGER DEFAULT 0")
    conn.commit()
    return conn

# ==========================================
# CLASSES (PARADIGMA ORIENTADO A OBJETOS)
# ==========================================

# 1. Classe Base e Encapsulamento
class Entidade:
    ALTURA_CORPO = 40
    LARGURA_CORPO = 40

    def __init__(self, x, y, vida_max, cor):
        self.x = x
        self.y = y
        self._vida = vida_max  # Encapsulamento: Vida protegida
        self.vida_max = vida_max
        self.cor = cor
        self.vivo = True

    @property
    def vida(self):
        return self._vida

    def receber_dano(self, dano):
        self._vida -= dano
        if self._vida <= 0:
            self._vida = 0
            self.vivo = False

    def desenhar(self, tela):
        pass # A ser implementado pelas subclasses

class Habilidade:
    """Skill usável: nivel 0 = bloqueada. Cooldown em frames, configurado em segundos."""
    def __init__(self, chave):
        self.chave = chave
        self.cfg = HABILIDADES_CFG[chave]
        self.nivel = 0
        self.timer = 0           # frames restantes de recarga
        self.ativa = 0           # frames restantes de efeito (laser)

    @property
    def desbloqueada(self):
        return self.nivel > 0

    @property
    def cooldown_frames(self):
        return self.cfg["cooldown"] * FPS

    @property
    def pronta(self):
        return self.desbloqueada and self.timer <= 0 and self.ativa <= 0

    @property
    def fracao_recarga(self):
        """0 = recém usada, 1 = pronta."""
        return 1 - max(0, self.timer) / self.cooldown_frames

    def usar(self):
        self.timer = self.cooldown_frames

    def atualizar(self):
        if self.timer > 0:
            self.timer -= 1
        if self.ativa > 0:
            self.ativa -= 1

    def zerar(self):
        self.timer = 0
        self.ativa = 0

# 2. Herança e Polimorfismo
class Jogador(Entidade):
    ALTURA_CORPO = 40
    LARGURA_CORPO = 40

    def __init__(self, nome):
        # y é o topo do corpo: os pés ficam exatamente em PE_Y
        super().__init__(110, PE_Y - self.ALTURA_CORPO, 100, (0, 255, 255)) # Ciano Neon
        self.nome = nome
        self.dinheiro = 0
        self.abates = 0
        self.nivel_ataque = 1
        self.nivel_vel_ataque = 1
        self.nivel_vida = 1

        # Status derivados dos níveis
        self.ataque_base = 10
        self.cooldown_ataque = 60 # Em frames (1 seg)
        self.timer_ataque = 0
        self.recuo = 0 # animação do canhão ao atirar

        # Progressão de fases e moeda especial (dropada pelos bosses)
        self.fase_concluida = 0   # 0..TOTAL_FASES; a fase jogada é fase_concluida + 1
        self.moedas = 0
        self.habilidades = {chave: Habilidade(chave) for chave in HABILIDADES_CFG}

    @property
    def fase_atual(self):
        return min(TOTAL_FASES, self.fase_concluida + 1)

    def _dados_extras(self):
        return (self.fase_concluida, self.moedas, self.habilidades["missil"].nivel,
                self.habilidades["laser"].nivel, self.habilidades["cura"].nivel)

    def _aplicar_extras(self, fase_concluida, moedas, missil, laser, cura):
        self.fase_concluida = int(fase_concluida or 0)
        self.moedas = int(moedas or 0)
        self.habilidades["missil"].nivel = int(missil or 0)
        self.habilidades["laser"].nivel = int(laser or 0)
        self.habilidades["cura"].nivel = int(cura or 0)

    def carregar_progresso(self, conn):
        if sys.platform == "emscripten":
            dados = conn.getItem(CHAVE_SAVE_WEB)
            if dados is None:
                dados = conn.getItem(self.nome)   # save da versão antiga (chave "Jogador1")
            try:
                if dados is None:
                    raise LookupError("sem save")
                progresso = json.loads(str(dados))
                valores = (int(progresso["dinheiro"]), int(progresso["nivel_ataque"]),
                           int(progresso["nivel_vel_ataque"]), int(progresso["nivel_vida"]),
                           int(progresso["abates"]))
            except (ValueError, KeyError, TypeError, LookupError):
                # Sem save ou save corrompido: começa do zero em vez de travar o jogo
                self.salvar_progresso(conn)
                return
            (self.dinheiro, self.nivel_ataque, self.nivel_vel_ataque,
             self.nivel_vida, self.abates) = valores
            self._aplicar_extras(progresso.get("fase_concluida"), progresso.get("moedas"),
                                 progresso.get("skill_missil"), progresso.get("skill_laser"),
                                 progresso.get("nivel_cura"))
            self.atualizar_status()
            return

        cursor = conn.cursor()
        cursor.execute("SELECT dinheiro, nivel_ataque, nivel_vel_ataque, nivel_vida, abates, "
                       "fase_concluida, moedas, skill_missil, skill_laser, nivel_cura "
                       "FROM jogador WHERE nome=?", (self.nome,))
        row = cursor.fetchone()
        if row:
            self.dinheiro, self.nivel_ataque, self.nivel_vel_ataque, self.nivel_vida, self.abates = row[0:5]
            self._aplicar_extras(*row[5:10])
            self.atualizar_status()
        else:
            self.salvar_progresso(conn)

    def salvar_progresso(self, conn):
        if sys.platform == "emscripten":
            extras = self._dados_extras()
            progresso = {
                "dinheiro": self.dinheiro,
                "nivel_ataque": self.nivel_ataque,
                "nivel_vel_ataque": self.nivel_vel_ataque,
                "nivel_vida": self.nivel_vida,
                "abates": self.abates,
                "fase_concluida": extras[0], "moedas": extras[1], "skill_missil": extras[2],
                "skill_laser": extras[3], "nivel_cura": extras[4],
            }
            conn.setItem(CHAVE_SAVE_WEB, json.dumps(progresso))
            return

        cursor = conn.cursor()
        cursor.execute('''
            INSERT OR REPLACE INTO jogador (nome, dinheiro, nivel_ataque, nivel_vel_ataque, nivel_vida, abates,
                                            fase_concluida, moedas, skill_missil, skill_laser, nivel_cura)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (self.nome, self.dinheiro, self.nivel_ataque, self.nivel_vel_ataque, self.nivel_vida, self.abates)
           + self._dados_extras())
        conn.commit()

    def limpar_progresso(self, conn):
        if sys.platform == "emscripten":
            conn.removeItem(CHAVE_SAVE_WEB)
            conn.removeItem(self.nome)
        else:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM jogador WHERE nome=?", (self.nome,))
            conn.commit()

        self.dinheiro = 0
        self.abates = 0
        self.nivel_ataque = 1
        self.nivel_vel_ataque = 1
        self.nivel_vida = 1
        self.fase_concluida = 0
        self.moedas = 0
        self.timer_ataque = 0
        self.recuo = 0
        self.vivo = True
        for hab in self.habilidades.values():
            hab.nivel = 0
            hab.zerar()
        self.atualizar_status()
        self.salvar_progresso(conn)

    def atualizar_status(self):
        self.ataque_base = 10 + (self.nivel_ataque * 5)
        self.cooldown_ataque = max(10, 60 - (self.nivel_vel_ataque * 5))
        self.vida_max = 100 + (self.nivel_vida * 20)
        self._vida = self.vida_max

    # Sobrescrita visual
    def desenhar(self, tela):
        agora = pygame.time.get_ticks()
        respiro = int(1 + math.sin(agora * 0.006))  # 0..2 px (idle)
        x = int(self.x)
        y = int(self.y) - respiro
        pes = int(self.y) + self.ALTURA_CORPO

        pulso = 0.75 + 0.25 * math.sin(agora * 0.006)
        brilho(tela, self.cor, (x + 20, y + 22), 55, 0.5 * pulso)

        # Sombra e brilho projetado no chão
        sombra_chao(tela, x + 20, pes, 50 - respiro * 3)
        brilho(tela, (0, 120, 130), (x + 20, pes), 34, 0.35 * pulso)

        # Canhão frontal (com recuo)
        cx = x - int(self.recuo)
        pygame.draw.rect(tela, (70, 90, 110), (cx + 34, y + 16, 14, 8), border_radius=3)
        pygame.draw.rect(tela, (150, 220, 255), (cx + 44, y + 17, 4, 6), border_radius=2)
        if self.recuo > 2:
            brilho(tela, (255, 220, 120), (cx + 50, y + 20), 18, 0.9)
        self.recuo = max(0, self.recuo - 0.6)

        # Corpo: contorno escuro + corpo + brilho interno
        pygame.draw.rect(tela, (0, 110, 120), (x, y, 40, 40), border_radius=8)
        pygame.draw.rect(tela, self.cor, (x + 2, y + 2, 36, 36), border_radius=7)
        pygame.draw.rect(tela, (170, 255, 255), (x + 5, y + 4, 30, 8), border_radius=5)

        # Botas (apoiadas no chão)
        pygame.draw.rect(tela, (0, 70, 85), (x + 4, y + 34, 13, 8), border_radius=3)
        pygame.draw.rect(tela, (0, 70, 85), (x + 23, y + 34, 13, 8), border_radius=3)
        pygame.draw.rect(tela, (60, 190, 200), (x + 4, y + 34, 13, 3), border_radius=2)
        pygame.draw.rect(tela, (60, 190, 200), (x + 23, y + 34, 13, 3), border_radius=2)

        # Visor
        pygame.draw.rect(tela, (10, 20, 40), (x + 18, y + 14, 18, 12), border_radius=4)
        pygame.draw.rect(tela, (120, 255, 200), (x + 26, y + 17, 7, 6), border_radius=2)
        pygame.draw.rect(tela, (255, 255, 255), (x + 27, y + 18, 2, 2))

        # Antena
        pygame.draw.line(tela, (150, 220, 255), (x + 8, y + 2), (x + 8, y - 6), 2)
        brilho(tela, (255, 80, 80), (x + 8, y - 6), 8, 0.4 + 0.5 * max(0, math.sin(agora * 0.01)))
        pygame.draw.circle(tela, (255, 90, 90), (x + 8, y - 6), 2)

        # Barra de Vida
        barra(tela, x - 2, y - 20, 44, 7, self._vida / self.vida_max, (60, 220, 90))

class Inimigo(Entidade):
    ALTURA_CORPO = 30
    LARGURA_CORPO = 30

    def __init__(self, hp_base, recompensa, deslocamento_x=0):
        # y é o topo do corpo: os pés ficam exatamente em PE_Y
        super().__init__(LARGURA + 50 + deslocamento_x, PE_Y - self.ALTURA_CORPO, hp_base, (255, 50, 50))
        self.velocidade = 2
        self.recompensa = recompensa
        self.fase = random.random() * 6.28  # defasagem do pulinho

    def atualizar(self):
        self.x -= self.velocidade

    def desenhar(self, tela):
        agora = pygame.time.get_ticks()
        salto = abs(math.sin(agora * 0.008 + self.fase)) * 8
        x = int(self.x)
        y = int(self.y - salto)
        pes = int(self.y) + self.ALTURA_CORPO

        brilho(tela, self.cor, (x + 15, y + 15), 38, 0.45)

        # Sombra (encolhe quando o inimigo pula)
        sombra_chao(tela, x + 15, pes, 34 - salto * 1.5)

        # Espinhos
        for i in range(3):
            pygame.draw.polygon(tela, (150, 20, 20),
                                [(x + 4 + i * 10, y), (x + 9 + i * 10, y - 7), (x + 14 + i * 10, y)])

        # Pezinhos
        pygame.draw.rect(tela, (90, 10, 10), (x + 3, y + 26, 10, 6), border_radius=2)
        pygame.draw.rect(tela, (90, 10, 10), (x + 17, y + 26, 10, 6), border_radius=2)

        # Corpo
        pygame.draw.rect(tela, (120, 15, 15), (x, y, 30, 30), border_radius=5)
        pygame.draw.rect(tela, self.cor, (x + 2, y + 2, 26, 26), border_radius=4)
        pygame.draw.rect(tela, (255, 130, 130), (x + 4, y + 4, 22, 5), border_radius=3)

        # Olhos zangados olhando para a esquerda
        for ox in (6, 17):
            pygame.draw.rect(tela, (255, 255, 230), (x + ox, y + 11, 8, 8), border_radius=2)
            pygame.draw.rect(tela, (30, 0, 0), (x + ox, y + 13, 4, 5))
            pygame.draw.line(tela, (80, 0, 0), (x + ox - 1, y + 9), (x + ox + 8, y + 12), 2)

        # Boca
        pygame.draw.rect(tela, (60, 0, 0), (x + 7, y + 22, 16, 4), border_radius=2)

        # Barra de vida (só aparece se ferido)
        if self._vida < self.vida_max:
            barra(tela, x, y - 16, 30, 5, self._vida / self.vida_max, (255, 200, 60))

class Boss(Inimigo):
    ALTURA_CORPO = 50
    LARGURA_CORPO = 50
    DANO_COLISAO = 100
    DANO_TIRO = 20
    INTERVALO_TIRO = 120

    def __init__(self, hp_base, recompensa):
        # Herda Inimigo mas muda propriedades (Polimorfismo estrutural)
        super().__init__(hp_base * 5, recompensa * 10)
        self.cor = (148, 0, 211) # Roxo
        self.velocidade = 1
        self.timer_tiro = 0

    def desenhar(self, tela):
        agora = pygame.time.get_ticks()
        flutua = (math.sin(agora * 0.004 + self.fase) + 1) * 3  # paira 0..6 px
        x = int(self.x)
        y = int(self.y - flutua)
        pes = int(self.y) + self.ALTURA_CORPO

        pulso = 0.7 + 0.3 * math.sin(agora * 0.008)
        brilho(tela, self.cor, (x + 25, y + 30), 80, 0.7 * pulso)

        # Sombra e reflexo no chão
        sombra_chao(tela, x + 25, pes, 62 - flutua * 2, alpha=120)
        brilho(tela, (90, 0, 140), (x + 25, pes), 44, 0.4 * pulso)

        pontos = [(x + 25, y), (x + 50, y + 50), (x, y + 50)]
        pygame.draw.polygon(tela, (70, 0, 110), pontos)
        interno = [(x + 25, y + 8), (x + 43, y + 46), (x + 7, y + 46)]
        pygame.draw.polygon(tela, self.cor, interno)
        pygame.draw.polygon(tela, (230, 150, 255), pontos, 2)

        # Olho central
        pygame.draw.circle(tela, (255, 240, 120), (x + 25, y + 32), 8)
        pygame.draw.circle(tela, (20, 0, 30), (x + 22, y + 32), 4)
        brilho(tela, (255, 220, 80), (x + 25, y + 32), 16, 0.8)

        # Barra de Vida do Boss
        barra(tela, x, y - 16, 50, 8, self._vida / self.vida_max, (200, 60, 255), fundo=(40, 10, 50))

# ==========================================
# DESENHO DOS 20 BOSSES (um design por fase)
# cada função recebe o retângulo (x, y, w, h) do corpo, a cor-base e o tempo em ms
# ==========================================
def _mix(cor, k):
    return tuple(max(0, min(255, int(v * k))) for v in cor)

def _olho(tela, cx, cy, r, iris=(30, 0, 0), esq=3):
    pygame.draw.circle(tela, (255, 255, 235), (cx, cy), r)
    pygame.draw.circle(tela, iris, (cx - esq, cy), max(1, r // 2))

def _boss_01(tela, x, y, w, h, cor, t):  # Rei Gosma
    sq = int(3 * math.sin(t * 0.008))
    pygame.draw.ellipse(tela, _mix(cor, .5), (x - sq, y + h * .3 + sq, w + sq * 2, h * .7 - sq))
    pygame.draw.ellipse(tela, cor, (x + 3 - sq, y + h * .3 + 3 + sq, w - 6 + sq * 2, h * .7 - 6 - sq))
    pygame.draw.ellipse(tela, _mix(cor, 1.5), (x + w * .2, y + h * .38, w * .3, h * .14))
    for ox in (.3, .62):
        _olho(tela, int(x + w * ox), int(y + h * .6), 7)
    pygame.draw.arc(tela, (20, 50, 20), (x + w * .3, y + h * .68, w * .4, h * .2), 3.4, 6.0, 3)
    pygame.draw.polygon(tela, (255, 210, 60), [(x + w * .22, y + h * .36), (x + w * .22, y + 2), (x + w * .36, y + h * .2),
                                               (x + w * .5, y - 4), (x + w * .64, y + h * .2), (x + w * .78, y + 2),
                                               (x + w * .78, y + h * .36)])
    pygame.draw.circle(tela, (255, 70, 90), (int(x + w * .5), int(y + h * .22)), 3)

def _boss_02(tela, x, y, w, h, cor, t):  # Aranha Tecelã
    cx, cy = x + w / 2, y + h * .45
    for i in range(4):
        for lado in (-1, 1):
            m = math.sin(t * 0.01 + i) * 6
            ponta = (cx + lado * (w * .55 + i * 2), y + h - 2 + (m if lado > 0 else -m) * .3)
            joelho = (cx + lado * (w * .42), y + 2 + i * 6 + m)
            pygame.draw.lines(tela, _mix(cor, .8), False, [(cx, cy), joelho, ponta], 3)
    pygame.draw.ellipse(tela, _mix(cor, .6), (cx - w * .3, cy - 4, w * .6, h * .5))
    pygame.draw.circle(tela, cor, (int(cx), int(cy)), int(w * .22))
    pygame.draw.polygon(tela, (255, 230, 60), [(cx - 6, cy + h * .18), (cx, cy + h * .3), (cx + 6, cy + h * .18)])
    for ox, oy in ((-8, -6), (-2, -9), (4, -9), (10, -6)):
        pygame.draw.circle(tela, (255, 40, 40), (int(cx + ox - 3), int(cy + oy)), 3)
    pygame.draw.polygon(tela, _mix(cor, 1.4), [(cx - 8, cy + 4), (cx - 3, cy + 14), (cx - 1, cy + 4)])
    pygame.draw.polygon(tela, _mix(cor, 1.4), [(cx + 2, cy + 4), (cx + 4, cy + 14), (cx + 9, cy + 4)])

def _boss_03(tela, x, y, w, h, cor, t):  # Morcego Colossal
    bat = math.sin(t * 0.012) * h * .28
    cx, cy = x + w / 2, y + h * .55
    for lado in (-1, 1):
        asa = [(cx, cy - 4), (cx + lado * w * .55, cy - h * .45 - bat), (cx + lado * w * .5, cy - 4 - bat * .3),
               (cx + lado * w * .38, cy + h * .22), (cx + lado * w * .22, cy + 4), (cx + lado * w * .1, cy + h * .25)]
        pygame.draw.polygon(tela, _mix(cor, .6), asa)
        pygame.draw.polygon(tela, cor, asa, 2)
    pygame.draw.ellipse(tela, _mix(cor, .8), (cx - 14, cy - 12, 28, 34))
    pygame.draw.polygon(tela, cor, [(cx - 13, cy - 8), (cx - 12, cy - 26), (cx - 3, cy - 12)])
    pygame.draw.polygon(tela, cor, [(cx + 13, cy - 8), (cx + 12, cy - 26), (cx + 3, cy - 12)])
    for ox in (-6, 6):
        pygame.draw.circle(tela, (255, 230, 60), (int(cx + ox), int(cy - 2)), 3)
    pygame.draw.polygon(tela, (255, 255, 255), [(cx - 5, cy + 7), (cx - 3, cy + 13), (cx - 1, cy + 7)])
    pygame.draw.polygon(tela, (255, 255, 255), [(cx + 1, cy + 7), (cx + 3, cy + 13), (cx + 5, cy + 7)])

def _boss_04(tela, x, y, w, h, cor, t):  # Golem de Pedra
    escuro = _mix(cor, .55)
    pygame.draw.rect(tela, escuro, (x + w * .15, y + h * .62, w * .28, h * .38), border_radius=4)
    pygame.draw.rect(tela, escuro, (x + w * .57, y + h * .62, w * .28, h * .38), border_radius=4)
    pygame.draw.rect(tela, _mix(cor, .75), (x + w * .1, y + h * .25, w * .8, h * .45), border_radius=6)
    pygame.draw.rect(tela, escuro, (x - 6, y + h * .3, w * .16, h * .4), border_radius=5)
    pygame.draw.rect(tela, escuro, (x + w * .9, y + h * .3, w * .16, h * .4), border_radius=5)
    pygame.draw.rect(tela, cor, (x + w * .25, y, w * .5, h * .32), border_radius=6)
    pygame.draw.line(tela, escuro, (x + w * .3, y + h * .5), (x + w * .5, y + h * .62), 2)
    pygame.draw.line(tela, escuro, (x + w * .5, y + h * .62), (x + w * .45, y + h * .7), 2)
    brilho_olho = 0.6 + 0.4 * math.sin(t * 0.006)
    for ox in (.36, .6):
        pygame.draw.rect(tela, (255, int(180 * brilho_olho), 40), (x + w * ox, y + h * .1, w * .09, h * .06))
    pygame.draw.circle(tela, (255, int(150 * brilho_olho), 40), (int(x + w * .5), int(y + h * .46)), 5)

def _boss_05(tela, x, y, w, h, cor, t):  # Caveira Flamejante
    cx = x + w / 2
    for i in range(7):
        fx = x + 4 + i * (w - 8) / 6
        alt = h * (.45 + .25 * math.sin(t * 0.012 + i * 1.7))
        pygame.draw.polygon(tela, (255, 90, 20), [(fx - 7, y + h * .5), (fx, y + h * .5 - alt), (fx + 7, y + h * .5)])
        pygame.draw.polygon(tela, (255, 200, 60), [(fx - 4, y + h * .5), (fx, y + h * .5 - alt * .6), (fx + 4, y + h * .5)])
    pygame.draw.ellipse(tela, (235, 230, 215), (cx - w * .3, y + h * .3, w * .6, h * .45))
    pygame.draw.rect(tela, (235, 230, 215), (cx - w * .2, y + h * .62, w * .4, h * .22), border_radius=3)
    for ox in (-.14, .14):
        pygame.draw.circle(tela, (30, 10, 10), (int(cx + w * ox), int(y + h * .5)), 7)
        pygame.draw.circle(tela, (255, 120, 30), (int(cx + w * ox), int(y + h * .5)), 3)
    pygame.draw.polygon(tela, (60, 30, 20), [(cx - 3, y + h * .6), (cx, y + h * .54), (cx + 3, y + h * .6)])
    for i in range(5):
        pygame.draw.line(tela, (80, 60, 50), (cx - w * .16 + i * w * .08, y + h * .72), (cx - w * .16 + i * w * .08, y + h * .84), 2)

def _boss_06(tela, x, y, w, h, cor, t):  # Polvo Abissal
    cx = x + w / 2
    for i in range(6):
        base = x + 8 + i * (w - 16) / 5
        pts = [(base + math.sin(t * 0.008 + i + k * .9) * (3 + k * 2), y + h * .5 + k * h * .1) for k in range(6)]
        pygame.draw.lines(tela, _mix(cor, .75), False, pts, 5)
        pygame.draw.circle(tela, (255, 160, 190), (int(pts[-1][0]), int(pts[-1][1])), 3)
    pygame.draw.ellipse(tela, _mix(cor, .6), (x + 2, y, w - 4, h * .68))
    pygame.draw.ellipse(tela, cor, (x + 6, y + 3, w - 12, h * .68 - 6))
    pygame.draw.ellipse(tela, _mix(cor, 1.6), (x + w * .2, y + 6, w * .3, h * .16))
    for ox in (.32, .68):
        _olho(tela, int(x + w * ox), int(y + h * .38), 8, iris=(80, 0, 90))
    for k in range(5):
        pygame.draw.circle(tela, _mix(cor, 1.5), (int(x + w * (.25 + k * .13)), int(y + h * .15 + (k % 2) * 6)), 2)

def _boss_07(tela, x, y, w, h, cor, t):  # Serpente de Cristal
    n = 9
    for i in range(n - 1, -1, -1):
        px = x + w * .08 + i * (w * .8 / n)
        py = y + h * .55 + math.sin(t * 0.006 + i * .8) * h * .22
        r = int(h * (.09 + .012 * (n - i)))
        pygame.draw.polygon(tela, _mix(cor, .6), [(px, py - r - 3), (px + r + 3, py), (px, py + r + 3), (px - r - 3, py)])
        pygame.draw.polygon(tela, cor if i % 2 else _mix(cor, 1.25), [(px, py - r), (px + r, py), (px, py + r), (px - r, py)])
    hx, hy = x + w * .06, y + h * .55 + math.sin(t * 0.006) * h * .22
    pygame.draw.polygon(tela, _mix(cor, 1.3), [(hx + 14, hy - 12), (hx - 20, hy), (hx + 14, hy + 12)])
    pygame.draw.circle(tela, (255, 60, 90), (int(hx), int(hy - 4)), 3)
    pygame.draw.line(tela, (255, 60, 90), (hx - 20, hy), (hx - 30, hy + 4), 2)
    pygame.draw.polygon(tela, (255, 255, 255), [(hx - 14, hy + 3), (hx - 12, hy + 10), (hx - 10, hy + 3)])

def _boss_08(tela, x, y, w, h, cor, t):  # Cavaleiro Sombrio
    cx = x + w / 2
    claro = _mix(cor, 1.6)
    pygame.draw.rect(tela, _mix(cor, .6), (cx - w * .3, y + h * .62, w * .24, h * .38), border_radius=3)
    pygame.draw.rect(tela, _mix(cor, .6), (cx + w * .06, y + h * .62, w * .24, h * .38), border_radius=3)
    pygame.draw.rect(tela, cor, (cx - w * .38, y + h * .28, w * .76, h * .42), border_radius=6)
    pygame.draw.rect(tela, claro, (cx - w * .38, y + h * .28, w * .76, 4), border_radius=2)
    pygame.draw.circle(tela, claro, (int(cx - w * .38), int(y + h * .3)), 9)
    pygame.draw.circle(tela, claro, (int(cx + w * .38), int(y + h * .3)), 9)
    pygame.draw.rect(tela, cor, (cx - w * .22, y, w * .44, h * .3), border_radius=8)
    pygame.draw.rect(tela, (20, 20, 30), (cx - w * .18, y + h * .1, w * .36, 6))
    pygame.draw.rect(tela, (255, 40, 40), (cx - w * .14, y + h * .11, w * .28, 3))
    pygame.draw.polygon(tela, (255, 40, 40), [(cx, y), (cx + 8, y - 14), (cx + 12, y + 2)])
    ang = math.sin(t * 0.006) * .25
    bx, by = cx - w * .5, y + h * .5
    pygame.draw.line(tela, (190, 200, 220), (bx, by), (bx - 6 + ang * 40, by - h * .55), 5)
    pygame.draw.line(tela, (240, 245, 255), (bx, by), (bx - 6 + ang * 40, by - h * .55), 2)
    pygame.draw.rect(tela, (150, 110, 40), (bx - 9, by - 3, 18, 5))

def _boss_09(tela, x, y, w, h, cor, t):  # Fantasma Uivante
    cx = x + w / 2
    pts = [(x, y + h * .35), (x + w * .15, y + 4), (cx, y - 4), (x + w * .85, y + 4), (x + w, y + h * .35), (x + w, y + h)]
    n = 6
    for i in range(n, -1, -1):
        pts.append((x + w * i / n, y + h - 4 + (8 if i % 2 else 0) * (1 + math.sin(t * 0.01 + i) * .4)))
    pygame.draw.polygon(tela, _mix(cor, .6), pts)
    pygame.draw.polygon(tela, cor, [(px + (cx - px) * .08, py + (y + h * .5 - py) * .08) for px, py in pts])
    for ox in (-.2, .2):
        pygame.draw.ellipse(tela, (20, 30, 60), (cx + w * ox - 8, y + h * .28, 16, 22))
        pygame.draw.circle(tela, (120, 200, 255), (int(cx + w * ox), int(y + h * .38)), 3)
    pygame.draw.ellipse(tela, (20, 30, 60), (cx - 10, y + h * (.55 + .05 * math.sin(t * 0.01)), 20, 24))
    for lado in (-1, 1):
        pygame.draw.line(tela, _mix(cor, .85), (cx + lado * w * .45, y + h * .5), (cx + lado * w * .62, y + h * .7), 6)

def _boss_10(tela, x, y, w, h, cor, t):  # Dragão Esmeralda
    escuro = _mix(cor, .55)
    bat = math.sin(t * 0.007) * 14
    pygame.draw.polygon(tela, escuro, [(x + w * .5, y + h * .45), (x + w * .35, y - 6 + bat), (x + w * .65, y + h * .1 + bat), (x + w * .8, y + h * .4)])
    pygame.draw.polygon(tela, (30, 120, 70), [(x + w * .5, y + h * .45), (x + w * .38, y + bat), (x + w * .55, y + h * .15 + bat * .6)])
    pygame.draw.polygon(tela, escuro, [(x + w, y + h * .55), (x + w * 1.12, y + h * .5), (x + w * .9, y + h * .75)])
    pygame.draw.ellipse(tela, escuro, (x + w * .2, y + h * .35, w * .75, h * .55))
    pygame.draw.ellipse(tela, cor, (x + w * .23, y + h * .38, w * .69, h * .45))
    pygame.draw.ellipse(tela, (230, 220, 150), (x + w * .28, y + h * .65, w * .5, h * .18))
    pygame.draw.rect(tela, escuro, (x + w * .3, y + h * .78, w * .12, h * .22), border_radius=3)
    pygame.draw.rect(tela, escuro, (x + w * .62, y + h * .78, w * .12, h * .22), border_radius=3)
    pygame.draw.polygon(tela, cor, [(x + w * .28, y + h * .4), (x + w * .05, y + h * .3), (x, y + h * .5), (x + w * .26, y + h * .62)])
    pygame.draw.circle(tela, (255, 230, 60), (int(x + w * .16), int(y + h * .36)), 3)
    pygame.draw.polygon(tela, (230, 220, 150), [(x + w * .12, y + h * .3), (x + w * .1, y + h * .12), (x + w * .2, y + h * .3)])
    f = 0.5 + 0.5 * math.sin(t * 0.02)
    pygame.draw.polygon(tela, (255, 120, 30), [(x, y + h * .46), (x - 24 * f - 6, y + h * .5), (x, y + h * .56)])

def _boss_11(tela, x, y, w, h, cor, t):  # Olho Cósmico
    cx, cy = x + w / 2, y + h / 2
    for k, (rx, ry) in enumerate(((w * .62, h * .18), (w * .5, h * .3))):
        a = t * 0.004 * (1 if k else -1)
        pts = [(cx + math.cos(a + i * .4) * rx * math.cos(a) - math.sin(a + i * .4) * ry * math.sin(a),
                cy + math.cos(a + i * .4) * rx * math.sin(a) + math.sin(a + i * .4) * ry * math.cos(a)) for i in range(16)]
        pygame.draw.lines(tela, _mix(cor, 1.4), True, pts, 2)
    pygame.draw.circle(tela, _mix(cor, .5), (int(cx), int(cy)), int(w * .38))
    pygame.draw.circle(tela, (245, 240, 255), (int(cx), int(cy)), int(w * .34))
    for i in range(10):
        a = i * .63
        pygame.draw.line(tela, (230, 90, 120), (cx + math.cos(a) * w * .22, cy + math.sin(a) * w * .22),
                         (cx + math.cos(a) * w * .33, cy + math.sin(a) * w * .33), 1)
    pygame.draw.circle(tela, cor, (int(cx - 6), int(cy)), int(w * .2))
    pygame.draw.circle(tela, (10, 0, 30), (int(cx - 8), int(cy)), int(w * .1))
    pygame.draw.circle(tela, (255, 255, 255), (int(cx - 12), int(cy - 5)), 3)

def _boss_12(tela, x, y, w, h, cor, t):  # Escorpião de Ferro
    escuro = _mix(cor, .55)
    for i in range(4):
        px = x + w * (.3 + i * .14)
        m = math.sin(t * 0.01 + i) * 3
        pygame.draw.lines(tela, escuro, False, [(px, y + h * .75), (px - 8, y + h * .95 + m), (px - 14, y + h)], 3)
    for k in range(5):
        a = k * .5
        px, py = x + w * .78 + math.sin(a) * w * .16 * (k + 1) * .35, y + h * .65 - k * h * .14
        pygame.draw.circle(tela, escuro, (int(px), int(py)), 8 - k)
        pygame.draw.circle(tela, cor, (int(px), int(py)), 6 - k)
    pygame.draw.polygon(tela, (230, 70, 50), [(x + w * .72, y + h * .02), (x + w * .66, y - 8), (x + w * .6, y + h * .08)])
    pygame.draw.ellipse(tela, escuro, (x + w * .15, y + h * .4, w * .65, h * .45))
    pygame.draw.ellipse(tela, cor, (x + w * .18, y + h * .43, w * .59, h * .36))
    for i in range(4):
        pygame.draw.line(tela, escuro, (x + w * (.3 + i * .12), y + h * .45), (x + w * (.3 + i * .12), y + h * .78), 2)
    for lado in (0, 1):
        py = y + h * (.38 + lado * .24)
        pygame.draw.polygon(tela, cor, [(x + w * .2, py), (x, py - 8), (x - 6, py + 2), (x + w * .1, py + 12)])
        pygame.draw.polygon(tela, escuro, [(x + w * .2, py), (x, py - 8), (x - 6, py + 2), (x + w * .1, py + 12)], 2)
    pygame.draw.circle(tela, (255, 70, 70), (int(x + w * .26), int(y + h * .52)), 3)

def _boss_13(tela, x, y, w, h, cor, t):  # Árvore Corrompida
    cx = x + w / 2
    balanco = math.sin(t * 0.004) * 4
    for lado in (-1, 1):
        for k in range(3):
            pygame.draw.line(tela, _mix(cor, .7), (cx, y + h * (.45 + k * .1)),
                             (cx + lado * w * (.55 - k * .08) + balanco, y + h * (.2 + k * .1)), 5 - k)
    pygame.draw.polygon(tela, cor, [(cx - w * .3, y + h), (cx - w * .18, y + h * .35), (cx + w * .18, y + h * .35), (cx + w * .3, y + h)])
    pygame.draw.polygon(tela, _mix(cor, .6), [(cx + w * .05, y + h * .4), (cx + w * .18, y + h * .35), (cx + w * .3, y + h), (cx + w * .1, y + h)])
    for ox, oy, r in ((-.28, .12, 20), (0, 0, 24), (.28, .12, 20), (-.1, .22, 18), (.14, .2, 18)):
        pygame.draw.circle(tela, (70, 40, 100), (int(cx + w * ox + balanco), int(y + h * oy + r * .5)), r)
        pygame.draw.circle(tela, (110, 60, 150), (int(cx + w * ox + balanco), int(y + h * oy + r * .5)), r - 5)
    for ox in (-.1, .1):
        pygame.draw.polygon(tela, (255, 180, 40), [(cx + w * ox - 6, y + h * .5), (cx + w * ox + 6, y + h * .5), (cx + w * ox, y + h * .58)])
    pygame.draw.polygon(tela, (30, 10, 20), [(cx - 9, y + h * .66), (cx, y + h * .6), (cx + 9, y + h * .66), (cx, y + h * .76)])

def _boss_14(tela, x, y, w, h, cor, t):  # Sentinela Robô
    cx = x + w / 2
    escuro = _mix(cor, .5)
    for lado in (-1, 1):
        pygame.draw.rect(tela, escuro, (cx + lado * w * .2 - 8, y + h * .68, 16, h * .32), border_radius=3)
    pygame.draw.rect(tela, escuro, (cx - w * .4, y + h * .3, w * .8, h * .42), border_radius=6)
    pygame.draw.rect(tela, cor, (cx - w * .36, y + h * .33, w * .72, h * .34), border_radius=5)
    pygame.draw.rect(tela, _mix(cor, 1.3), (cx - w * .36, y + h * .33, w * .72, 5), border_radius=3)
    pygame.draw.rect(tela, (50, 60, 80), (cx - w * .6, y + h * .4, w * .26, h * .12))
    pygame.draw.rect(tela, (255, 120, 40), (cx - w * .66, y + h * .42, 8, h * .08))
    pygame.draw.rect(tela, escuro, (cx - w * .26, y + h * .02, w * .52, h * .3), border_radius=6)
    pygame.draw.circle(tela, (20, 0, 0), (int(cx), int(y + h * .16)), 11)
    pulso = 0.5 + 0.5 * math.sin(t * 0.01)
    pygame.draw.circle(tela, (255, int(60 + 120 * pulso), 50), (int(cx), int(y + h * .16)), 7)
    pygame.draw.line(tela, (190, 200, 220), (cx + w * .15, y + h * .02), (cx + w * .15, y - 12), 2)
    pygame.draw.circle(tela, (255, 70, 70) if pulso > .5 else (120, 30, 30), (int(cx + w * .15), int(y - 12)), 3)
    for i in range(3):
        pygame.draw.circle(tela, (40, 50, 70), (int(cx - w * .2 + i * w * .2), int(y + h * .55)), 3)

def _boss_15(tela, x, y, w, h, cor, t):  # Fênix Negra
    cx, cy = x + w / 2, y + h * .5
    bat = math.sin(t * 0.01) * h * .3
    for i in range(5):
        a = (i - 2) * .22
        pygame.draw.polygon(tela, (255, 140 - i * 18, 30), [(cx + 10, cy + 6), (cx + w * .5 + 12 * i, cy + h * .35 + math.sin(t * 0.012 + i) * 6 + i * 6),
                                                          (cx + 14, cy + 12)])
    for lado in (-1, 1):
        for k in range(4):
            pygame.draw.polygon(tela, _mix(cor, 1.1 - k * .12), [(cx, cy - 4 + k * 4), (cx - w * .22 - k * 6, cy - h * .5 - bat * lado * .0 - bat + k * 12),
                                                                (cx - w * .12 - k * 4, cy + 4 + k * 4)])
    pygame.draw.ellipse(tela, (40, 20, 45), (cx - w * .26, cy - h * .16, w * .5, h * .36))
    pygame.draw.circle(tela, (60, 30, 60), (int(cx - w * .26), int(cy - h * .12)), int(h * .13))
    pygame.draw.polygon(tela, (255, 190, 50), [(cx - w * .36, cy - h * .13), (cx - w * .48, cy - h * .08), (cx - w * .35, cy - h * .06)])
    pygame.draw.circle(tela, (255, 230, 80), (int(cx - w * .28), int(cy - h * .14)), 3)
    pygame.draw.polygon(tela, cor, [(cx - w * .26, cy - h * .24), (cx - w * .22, cy - h * .36), (cx - w * .16, cy - h * .22)])

def _boss_16(tela, x, y, w, h, cor, t):  # Gárgula de Gelo
    cx = x + w / 2
    escuro = _mix(cor, .5)
    bat = math.sin(t * 0.006) * 8
    for lado in (-1, 1):
        pygame.draw.polygon(tela, escuro, [(cx, y + h * .4), (cx + lado * w * .6, y + h * .05 + bat), (cx + lado * w * .45, y + h * .5), (cx + lado * w * .2, y + h * .6)])
        pygame.draw.polygon(tela, (190, 235, 255), [(cx, y + h * .4), (cx + lado * w * .6, y + h * .05 + bat), (cx + lado * w * .45, y + h * .5), (cx + lado * w * .2, y + h * .6)], 2)
    pygame.draw.polygon(tela, cor, [(cx - w * .26, y + h * .95), (cx - w * .2, y + h * .4), (cx + w * .2, y + h * .4), (cx + w * .26, y + h * .95)])
    pygame.draw.polygon(tela, _mix(cor, 1.3), [(cx - w * .2, y + h * .4), (cx - w * .05, y + h * .4), (cx - w * .1, y + h * .9), (cx - w * .24, y + h * .9)])
    pygame.draw.circle(tela, cor, (int(cx), int(y + h * .26)), int(w * .2))
    for lado in (-1, 1):
        pygame.draw.polygon(tela, (220, 245, 255), [(cx + lado * w * .12, y + h * .14), (cx + lado * w * .22, y - 6), (cx + lado * w * .2, y + h * .16)])
        pygame.draw.circle(tela, (40, 120, 255), (int(cx + lado * w * .08), int(y + h * .26)), 4)
    pygame.draw.polygon(tela, (255, 255, 255), [(cx - 5, y + h * .36), (cx - 3, y + h * .42), (cx - 1, y + h * .36)])
    pygame.draw.polygon(tela, (255, 255, 255), [(cx + 1, y + h * .36), (cx + 3, y + h * .42), (cx + 5, y + h * .36)])
    for i in range(3):
        pygame.draw.polygon(tela, (220, 245, 255), [(cx - w * .3 + i * 8, y + h), (cx - w * .3 + i * 8 + 4, y + h + 7), (cx - w * .3 + i * 8 + 8, y + h)])

def _boss_17(tela, x, y, w, h, cor, t):  # Lich
    cx = x + w / 2
    pygame.draw.polygon(tela, (40, 20, 70), [(cx - w * .2, y + h * .3), (cx + w * .2, y + h * .3), (cx + w * .45, y + h), (cx - w * .45, y + h)])
    pygame.draw.polygon(tela, (70, 40, 120), [(cx - w * .12, y + h * .35), (cx + w * .12, y + h * .35), (cx + w * .2, y + h), (cx - w * .2, y + h)])
    pygame.draw.circle(tela, (235, 235, 215), (int(cx), int(y + h * .22)), int(w * .17))
    pygame.draw.rect(tela, (235, 235, 215), (cx - w * .09, y + h * .3, w * .18, h * .07))
    for ox in (-.07, .07):
        pygame.draw.circle(tela, cor, (int(cx + w * ox), int(y + h * .22)), 4)
    pygame.draw.polygon(tela, (255, 210, 60), [(cx - w * .17, y + h * .12), (cx - w * .13, y - 4), (cx - w * .05, y + h * .08), (cx, y - 8),
                                               (cx + w * .05, y + h * .08), (cx + w * .13, y - 4), (cx + w * .17, y + h * .12)])
    bx = cx + w * .5
    pygame.draw.line(tela, (120, 90, 50), (bx, y + h * .2), (bx, y + h), 4)
    pulso = 0.6 + 0.4 * math.sin(t * 0.01)
    brilho(tela, cor, (bx, y + h * .15), 26, pulso)
    pygame.draw.circle(tela, cor, (int(bx), int(y + h * .15)), 7)
    for i in range(3):
        a = t * 0.005 + i * 2.09
        pygame.draw.circle(tela, cor, (int(cx + math.cos(a) * w * .5), int(y + h * .5 + math.sin(a) * h * .18)), 4)

def _boss_18(tela, x, y, w, h, cor, t):  # Demônio de Lava
    cx = x + w / 2
    escuro = (50, 18, 12)
    pygame.draw.rect(tela, escuro, (cx - w * .3, y + h * .6, w * .24, h * .4), border_radius=4)
    pygame.draw.rect(tela, escuro, (cx + w * .06, y + h * .6, w * .24, h * .4), border_radius=4)
    pygame.draw.rect(tela, (70, 24, 16), (cx - w * .4, y + h * .25, w * .8, h * .45), border_radius=8)
    pulso = 0.6 + 0.4 * math.sin(t * 0.006)
    cor_lava = (255, int(70 + 90 * pulso), 20)
    for pts in (((.3, .35), (.45, .5), (.4, .62)), ((.7, .38), (.58, .55), (.66, .66)), ((.48, .3), (.52, .46))):
        pygame.draw.lines(tela, cor_lava, False, [(x + w * a, y + h * b) for a, b in pts], 3)
    for lado in (-1, 1):
        pygame.draw.circle(tela, (70, 24, 16), (int(cx + lado * w * .5), int(y + h * .42)), 12)
        pygame.draw.circle(tela, cor_lava, (int(cx + lado * w * .5), int(y + h * .42)), 5)
    pygame.draw.rect(tela, (90, 30, 20), (cx - w * .24, y + h * .02, w * .48, h * .28), border_radius=8)
    for lado in (-1, 1):
        pygame.draw.polygon(tela, (230, 210, 170), [(cx + lado * w * .18, y + h * .08), (cx + lado * w * .36, y - 10), (cx + lado * w * .26, y + h * .12)])
        pygame.draw.polygon(tela, (255, 230, 80), [(cx + lado * w * .17 - 6, y + h * .14), (cx + lado * w * .17 + 6, y + h * .14), (cx + lado * w * .1, y + h * .2)])
    pygame.draw.polygon(tela, (20, 0, 0), [(cx - 12, y + h * .24), (cx + 12, y + h * .24), (cx, y + h * .16)])
    for i in range(3):
        gy = y + h * .7 + ((t * 0.05 + i * 14) % (h * .3))
        pygame.draw.circle(tela, cor_lava, (int(cx - w * .2 + i * w * .2), int(gy)), 3)

def _boss_19(tela, x, y, w, h, cor, t):  # Hidra
    escuro = _mix(cor, .55)
    base = (x + w * .6, y + h * .85)
    pygame.draw.ellipse(tela, escuro, (x + w * .3, y + h * .62, w * .7, h * .38))
    pygame.draw.ellipse(tela, cor, (x + w * .33, y + h * .65, w * .64, h * .3))
    for k, (ang, comp) in enumerate(((-.9, .8), (0, 1.0), (.9, .8))):
        bal = math.sin(t * 0.005 + k * 2) * .18
        pts = []
        for s in range(6):
            q = s / 5
            pts.append((base[0] - math.sin(ang + bal) * q * w * .55 - q * w * .15,
                        base[1] - math.cos((ang + bal) * .6) * q * h * comp * .75))
        pygame.draw.lines(tela, escuro, False, pts, 9)
        pygame.draw.lines(tela, cor, False, pts, 5)
        hx, hy = pts[-1]
        pygame.draw.circle(tela, escuro, (int(hx), int(hy)), 8)
        pygame.draw.polygon(tela, cor, [(hx, hy - 7), (hx - 16, hy + 2), (hx, hy + 7)])
        pygame.draw.circle(tela, (255, 230, 60), (int(hx - 2), int(hy - 3)), 2)
        pygame.draw.line(tela, (255, 70, 90), (hx - 16, hy + 2), (hx - 22, hy + 4), 1)

def _boss_20(tela, x, y, w, h, cor, t):  # Devorador de Mundos
    cx, cy = x + w / 2, y + h / 2
    brilho(tela, (170, 60, 255), (cx, cy), int(w * .85), 0.8)
    pygame.draw.circle(tela, (25, 0, 40), (int(cx), int(cy)), int(w * .5))
    for anel, (raio, vel) in enumerate(((.5, 1), (.38, -1.4), (.26, 2))):
        for i in range(14):
            a = t * 0.002 * vel + i * 6.283 / 14
            px, py = cx + math.cos(a) * w * raio, cy + math.sin(a) * h * raio
            ang = a + 1.57
            pygame.draw.polygon(tela, (240, 235, 220), [(px, py), (px - math.cos(a) * 12 * (1 - anel * .2) + math.cos(ang) * 4,
                                                           py - math.sin(a) * 12 * (1 - anel * .2) + math.sin(ang) * 4),
                                                          (px - math.cos(a) * 12 * (1 - anel * .2) - math.cos(ang) * 4,
                                                           py - math.sin(a) * 12 * (1 - anel * .2) - math.sin(ang) * 4)])
    pygame.draw.circle(tela, (0, 0, 0), (int(cx), int(cy)), int(w * .17))
    for i in range(16):
        ex, ey = cx + math.cos(i * 2.4 + t * 0.001) * w * .3, cy + math.sin(i * 1.7) * h * .3
        pygame.draw.circle(tela, (230, 200, 255), (int(ex), int(ey)), 1)
    pygame.draw.circle(tela, (255, 80, 160), (int(cx), int(cy)), int(w * .17), 2)

# nome, cor, (largura, altura), voo (px acima do chão), vida x, velocidade, intervalo de tiro (frames), padrão, dano x, desenho
BOSSES = [
    ("Rei Gosma",            (60, 200, 90),   (70, 60),   0, 1.0, 1.0, 130, "reto",     1.0, _boss_01),
    ("Aranha Tecelã",        (170, 40, 70),   (84, 56),   0, 1.0, 1.3, 110, "mira",     1.0, _boss_02),
    ("Morcego Colossal",     (120, 80, 180),  (90, 62),  46, 1.1, 1.4, 100, "triplo",   1.0, _boss_03),
    ("Golem de Pedra",       (135, 135, 145), (80, 92),   0, 1.6, 0.8, 120, "reto",     1.3, _boss_04),
    ("Caveira Flamejante",   (255, 120, 30),  (64, 72),  24, 1.1, 1.2,  95, "rajada",   1.0, _boss_05),
    ("Polvo Abissal",        (50, 130, 210),  (84, 74),   0, 1.3, 1.0, 105, "chuva",    1.0, _boss_06),
    ("Serpente de Cristal",  (80, 230, 230),  (100, 80),  0, 1.2, 1.5, 100, "mira",     1.1, _boss_07),
    ("Cavaleiro Sombrio",    (70, 70, 105),   (70, 100),  0, 1.5, 1.1,  90, "triplo",   1.2, _boss_08),
    ("Fantasma Uivante",     (205, 225, 255), (70, 90),  34, 1.2, 1.3,  85, "circular", 1.0, _boss_09),
    ("Dragão Esmeralda",     (40, 175, 95),   (110, 80),  0, 1.6, 1.0,  95, "rajada",   1.3, _boss_10),
    ("Olho Cósmico",         (160, 60, 255),  (90, 90),  38, 1.4, 1.1,  80, "circular", 1.2, _boss_11),
    ("Escorpião de Ferro",   (155, 165, 185), (100, 66),  0, 1.7, 1.2,  90, "mira",     1.3, _boss_12),
    ("Árvore Corrompida",    (110, 72, 42),   (84, 112),  0, 2.0, 0.7,  85, "chuva",    1.2, _boss_13),
    ("Sentinela Robô",       (180, 190, 215), (76, 98),   0, 1.8, 1.0,  75, "rajada",   1.3, _boss_14),
    ("Fênix Negra",         (255, 70, 100),   (100, 80), 50, 1.5, 1.6,  80, "triplo",   1.3, _boss_15),
    ("Gárgula de Gelo",      (150, 215, 255), (84, 96),  18, 1.9, 1.2,  80, "mira",     1.4, _boss_16),
    ("Lich",                 (120, 255, 140), (82, 100),  8, 1.8, 1.0,  70, "circular", 1.4, _boss_17),
    ("Demônio de Lava",      (255, 100, 35),  (90, 102),  0, 2.4, 0.9,  70, "rajada",   1.5, _boss_18),
    ("Hidra",                (55, 165, 115),  (120, 92),  0, 2.6, 0.9,  65, "triplo",   1.5, _boss_19),
    ("Devorador de Mundos",  (190, 70, 255),  (130, 122), 12, 3.2, 0.8,  55, "circular", 1.7, _boss_20),
]

class BossFase(Boss):
    """Boss único de cada fase: visual, tamanho, vida e padrão de tiro vêm da tabela BOSSES."""
    def __init__(self, fase):
        nome, cor, (w, h), voo, mult_vida, vel, intervalo, padrao, mult_dano, desenho = BOSSES[fase - 1]
        hp = int((200 + fase * 90) * mult_vida)
        super().__init__(hp // 5, 10 + fase * 4)   # Boss multiplica vida por 5 e recompensa por 10
        self.recompensa = (10 + fase * 4) * 5
        self.fase_boss = fase
        self.nome = nome
        self.cor = cor
        self.LARGURA_CORPO, self.ALTURA_CORPO = w, h
        self.voo = voo
        self.velocidade = vel
        self.intervalo_base = intervalo
        self.padrao = padrao
        self.dano_tiro = int((8 + fase * 3) * mult_dano)
        self.desenho = desenho
        self.y = PE_Y - h - voo
        self.rajada = 0          # tiros restantes da rajada
        self.timer_rajada = 0

    @property
    def INTERVALO_TIRO(self):
        enfurecido = self._vida < self.vida_max * 0.5
        return int(self.intervalo_base * (0.7 if enfurecido else 1))

    def disparar(self, jogador):
        """Cria os projéteis do padrão deste boss. Retorna uma lista de ProjetilBoss."""
        ox, oy = self.x, self.y + self.ALTURA_CORPO * 0.5
        alvo_x, alvo_y = jogador.x + 20, jogador.y + 20
        base = math.atan2(alvo_y - oy, alvo_x - ox)
        mk = lambda ang, vel=7: ProjetilBoss(ox, oy, self.dano_tiro, vx=math.cos(ang) * vel,
                                              vy=math.sin(ang) * vel, cor=self.cor)
        if self.padrao == "reto":
            return [ProjetilBoss(ox, oy, self.dano_tiro, cor=self.cor)]
        if self.padrao == "mira":
            return [mk(base, 8)]
        if self.padrao == "triplo":
            return [mk(base + d) for d in (-0.22, 0, 0.22)]
        if self.padrao == "rajada":
            self.rajada, self.timer_rajada = 3, 0
            return []
        if self.padrao == "chuva":
            return [ProjetilBoss(random.randint(250, 620), -10, self.dano_tiro, vx=-2.5, vy=6, cor=self.cor) for _ in range(3)]
        if self.padrao == "circular":
            return [mk(math.pi + (i - 3.5) * 0.35, 5.5) for i in range(8)]
        return []

    def continuar_rajada(self, jogador):
        """Dispara os tiros da rajada, um a cada 8 frames."""
        if self.rajada <= 0:
            return []
        self.timer_rajada += 1
        if self.timer_rajada < 8:
            return []
        self.timer_rajada = 0
        self.rajada -= 1
        ox, oy = self.x, self.y + self.ALTURA_CORPO * 0.5
        ang = math.atan2(jogador.y + 20 - oy, jogador.x + 20 - ox)
        return [ProjetilBoss(ox, oy, self.dano_tiro, vx=math.cos(ang) * 8, vy=math.sin(ang) * 8, cor=self.cor)]

    def desenhar(self, tela):
        agora = pygame.time.get_ticks()
        w, h = self.LARGURA_CORPO, self.ALTURA_CORPO
        flutua = (math.sin(agora * 0.004 + self.fase) + 1) * (4 if self.voo else 1.5)
        x = int(self.x)
        y = int(self.y - flutua)
        pes = PE_Y

        pulso = 0.7 + 0.3 * math.sin(agora * 0.008)
        brilho(tela, self.cor, (x + w / 2, y + h * 0.55), int(max(w, h) * 0.85), 0.55 * pulso)
        sombra_chao(tela, x + w / 2, pes, w * 1.05 - self.voo * 0.4, alpha=120)
        self.desenho(tela, x, y, w, h, self.cor, agora)

        barra(tela, x + w // 2 - 35, y - 18 - (6 if self.voo else 0), 70, 8, self._vida / self.vida_max,
              (230, 70, 90), fundo=(45, 10, 25))

class Projetil:
    def __init__(self, x, y, dano):
        self.x = x
        self.y = y + 20
        self.dano = dano
        self.velocidade = 10
        self.ativo = True

    def atualizar(self):
        self.x += self.velocidade
        if self.x > LARGURA:
            self.ativo = False

    def desenhar(self, tela):
        px, py = int(self.x), int(self.y)
        # Rastro de luz
        for i in range(1, 6):
            r = max(1, 5 - i)
            cor = (255, 200 - i * 25, 40)
            pygame.draw.circle(tela, cor, (px - i * 6, py), r)
        brilho(tela, (255, 220, 60), (px, py), 20, 0.9)
        pygame.draw.circle(tela, (255, 180, 0), (px, py), 5)
        pygame.draw.circle(tela, (255, 255, 220), (px, py), 3)

class ProjetilBoss:
    def __init__(self, x, y, dano, vx=None, vy=0, cor=(190, 40, 255)):
        self.x = x
        self.y = y
        self.dano = dano
        self.velocidade = 8
        self.vx = -self.velocidade if vx is None else vx
        self.vy = vy
        self.cor = cor
        self.ativo = True

    def atualizar(self):
        self.x += self.vx
        self.y += self.vy
        if self.x < 0 or self.y < 0 or self.y > ALTURA:
            self.ativo = False

    def desenhar(self, tela):
        px, py = int(self.x), int(self.y)
        claro = tuple(min(255, c + 90) for c in self.cor)
        brilho(tela, self.cor, (px, py), 18, 0.8)
        pygame.draw.circle(tela, self.cor, (px, py), 6)
        pygame.draw.circle(tela, claro, (px, py), 3)

class Missil:
    """Míssil da skill: voa até o primeiro inimigo e explode em área."""
    RAIO_EXPLOSAO = 90

    def __init__(self, x, y):
        self.x, self.y = x, y
        self.dano = MISSIL_DANO
        self.velocidade = 9
        self.ativo = True

    def atualizar(self):
        self.x += self.velocidade
        if self.x > LARGURA + 40:
            self.ativo = False

    def desenhar(self, tela):
        px, py = int(self.x), int(self.y)
        for i in range(1, 7):
            pygame.draw.circle(tela, (255, 170 - i * 18, 40), (px - i * 7, py + random.randint(-1, 1)), max(1, 6 - i))
        brilho(tela, (255, 150, 60), (px - 8, py), 26, 0.9)
        pygame.draw.polygon(tela, (220, 220, 235), [(px + 14, py), (px - 8, py - 5), (px - 8, py + 5)])
        pygame.draw.polygon(tela, (230, 70, 50), [(px - 8, py - 5), (px - 14, py - 9), (px - 4, py)])
        pygame.draw.polygon(tela, (230, 70, 50), [(px - 8, py + 5), (px - 14, py + 9), (px - 4, py)])

def desenhar_laser(tela, x0, y0, frames_restantes):
    """Feixe contínuo do jogador até a borda direita da tela."""
    t = pygame.time.get_ticks() * 0.03
    esp = 7 + int(2 * math.sin(t))
    brilho(tela, (60, 190, 255), (x0 + 20, y0), 40, 0.8)
    pygame.draw.rect(tela, (40, 140, 230), (x0, y0 - esp, LARGURA - x0, esp * 2), border_radius=4)
    pygame.draw.rect(tela, (170, 240, 255), (x0, y0 - esp // 2, LARGURA - x0, max(2, esp)), border_radius=3)
    pygame.draw.rect(tela, (255, 255, 255), (x0, y0 - 1, LARGURA - x0, 2))
    for i in range(5):
        px = x0 + ((t * 9 + i * 160) % (LARGURA - x0))
        pygame.draw.circle(tela, (210, 250, 255), (int(px), int(y0 + math.sin(t + i) * esp)), 2)

class Particula:
    """Faísca de impacto / explosão."""
    def __init__(self, x, y, cor, vx=None, vy=None, vida=None, tam=None):
        ang = random.uniform(0, 6.283)
        vel = random.uniform(1, 5)
        self.x, self.y = x, y
        self.vx = vx if vx is not None else math.cos(ang) * vel
        self.vy = vy if vy is not None else math.sin(ang) * vel - 1.5
        self.vida = self.vida_max = vida or random.randint(20, 40)
        self.tam = tam or random.uniform(2, 4)
        self.cor = cor

    def atualizar(self):
        self.x += self.vx
        self.y += self.vy
        self.vy += 0.15
        self.vida -= 1

    def desenhar(self, tela):
        f = max(0, self.vida / self.vida_max)
        r = max(1, int(self.tam * f + 0.5))
        cor = (int(self.cor[0] * (0.4 + 0.6 * f)), int(self.cor[1] * (0.4 + 0.6 * f)), int(self.cor[2] * (0.4 + 0.6 * f)))
        pygame.draw.circle(tela, cor, (int(self.x), int(self.y)), r)

class TextoFlutuante:
    """Número de dano / ouro que sobe e some."""
    def __init__(self, texto, cor, x, y):
        self.surf = FONTE_NUM.render(texto, True, cor)
        self.sombra = FONTE_NUM.render(texto, True, (0, 0, 0))
        self.x, self.y = x - self.surf.get_width() / 2, y
        self.vida = self.vida_max = 50

    def atualizar(self):
        self.y -= 0.8
        self.vida -= 1

    def desenhar(self, tela):
        alpha = int(255 * min(1, self.vida / (self.vida_max * 0.5)))
        self.surf.set_alpha(alpha)
        self.sombra.set_alpha(alpha)
        tela.blit(self.sombra, (int(self.x) + 1, int(self.y) + 1))
        tela.blit(self.surf, (int(self.x), int(self.y)))

class EsteticaFase:
    def __init__(self):
        self.tempo = 0
        self.mundo = 0
        self.decoracoes = []
        self.ceu = gradiente_vertical(LARGURA, ALTURA, (6, 6, 24), (62, 30, 74))
        self.chao = gradiente_vertical(LARGURA, ALTURA - HORIZONTE, (30, 70, 42), (6, 18, 14))
        self.cor_neblina = (90, 150, 140)
        self.neblina = self._criar_neblina()
        rng = random.Random(7)  # gerador próprio: não interfere no random do jogo
        self.estrelas = [(rng.randint(0, LARGURA), rng.randint(0, HORIZONTE - 140),
                          rng.choice((1, 1, 2)), rng.random() * 6.28) for _ in range(90)]
        self.montanhas_longe = self._criar_montanhas((34, 30, 66), 150, (2, 5, 9), 11)
        self.montanhas_perto = self._criar_montanhas((20, 26, 42), 95, (3, 6, 8), 29)
        self.nuvens = [(rng.randint(0, LARGURA), rng.randint(70, 250), rng.uniform(0.12, 0.35),
                        self._criar_nuvem(rng)) for _ in range(5)]
        self.vagalumes = [[rng.random() * LARGURA, rng.uniform(HORIZONTE - 70, ALTURA - 25),
                           rng.random() * 6.28, rng.uniform(0.5, 1.4)] for _ in range(16)]
        # tufos de grama: (x, y, altura, velocidade) — mais perto da câmera = mais rápido
        self.tufos = []
        for _ in range(46):
            ty = rng.randint(HORIZONTE + 6, ALTURA - 6)
            self.tufos.append((rng.randint(0, LARGURA), ty, rng.randint(5, 11),
                               0.5 + (ty - HORIZONTE) / 100 * 1.2))

    def definir_fase(self, fase):
        """Troca a paleta do cenário a cada 4 fases (5 mundos)."""
        mundo = min(len(TEMAS_MUNDO) - 1, (fase - 1) // 4)
        self.mundo = mundo
        ceu_topo, ceu_base, chao_topo, chao_base, neblina = TEMAS_MUNDO[mundo]
        self.ceu = gradiente_vertical(LARGURA, ALTURA, ceu_topo, ceu_base)
        self.chao = gradiente_vertical(LARGURA, ALTURA - HORIZONTE, chao_topo, chao_base)
        self.cor_neblina = neblina
        self.neblina = self._criar_neblina()
        self.montanhas_longe = self._criar_montanhas(
            tuple(int((ceu_base[i] + chao_topo[i]) / 3) for i in range(3)), 150, (2, 5, 9), 11
        )
        self.montanhas_perto = self._criar_montanhas(
            tuple(int(chao_base[i] * 1.6) for i in range(3)), 95, (3, 6, 8), 29
        )
        rng = random.Random(100 + mundo)
        if mundo == 0:
            self.decoracoes = [(rng.randint(10, LARGURA - 10), rng.randint(48, 82)) for _ in range(11)]
        elif mundo == 1:
            self.decoracoes = [(rng.randint(0, LARGURA), rng.randint(24, 48)) for _ in range(18)]
        elif mundo == 2:
            self.decoracoes = [(rng.randint(0, LARGURA), rng.randint(20, 65)) for _ in range(9)]
        elif mundo == 3:
            self.decoracoes = [(rng.randint(0, LARGURA), rng.randint(2, 5)) for _ in range(8)]
        else:
            self.decoracoes = [(rng.randint(90, LARGURA - 40), rng.randint(70, 170)) for _ in range(3)]
        self.nuvens = [
            (nx, ny, vel, self._criar_nuvem(random.Random(200 + mundo * 10 + i)))
            for i, (nx, ny, vel, _) in enumerate(self.nuvens)
        ]

    def _criar_nuvem(self, rng):
        surf = pygame.Surface((240, 60), pygame.SRCALPHA)
        cor = ((110, 85, 150), (105, 115, 145), (150, 210, 255),
               (145, 75, 55), (125, 65, 175))[self.mundo]
        for _ in range(7):
            w, h = rng.randint(70, 130), rng.randint(16, 30)
            pygame.draw.ellipse(surf, (*cor, 38), (rng.randint(0, 240 - w), rng.randint(8, 60 - h), w, h))
        return surf

    def _criar_neblina(self):
        altura = 70
        surf = pygame.Surface((LARGURA, altura), pygame.SRCALPHA)
        for y in range(altura):
            a = int(70 * (y / altura) ** 1.6)
            pygame.draw.line(surf, (*self.cor_neblina, a), (0, y), (LARGURA, y))
        return surf

    def _criar_montanhas(self, cor, altura_max, ondas, semente):
        # Perfil baseado em senoides inteiras: repete sem emendas visíveis
        rng = random.Random(semente)
        fases = [rng.random() * 6.28 for _ in ondas]
        surf = pygame.Surface((LARGURA, altura_max + 10), pygame.SRCALPHA)
        pontos = [(0, altura_max + 10)]
        for x in range(0, LARGURA + 1, 8):
            h = 0
            for k, ph in zip(ondas, fases):
                h += math.sin(2 * math.pi * k * x / LARGURA + ph) / len(ondas)
            y = altura_max * 0.55 - h * altura_max * 0.5 + altura_max * 0.2
            pontos.append((x, y))
        pontos.append((LARGURA, altura_max + 10))
        pygame.draw.polygon(surf, cor, pontos)
        return surf

    def _posicao_cenario(self, x, margem):
        largura_ciclo = LARGURA + margem * 2
        return int((x - self.tempo * 0.8) % largura_ciclo) - margem

    def _desenhar_detalhes_mundo(self, tela):
        if self.mundo == 0:
            t = pygame.time.get_ticks() * 0.001
            for i, (x, altura) in enumerate(self.decoracoes):
                margem = altura // 3 + 4
                x = self._posicao_cenario(x, margem)
                base = HORIZONTE + 4
                balanco = int(round(math.sin(t * 1.2 + i * 1.7) * 3))
                pygame.draw.polygon(tela, (30, 48, 34), [
                    (x - 3, base), (x + 3, base),
                    (x + balanco + 3, base - altura // 2),
                    (x + balanco - 3, base - altura // 2),
                ])
                for nivel in range(3):
                    y = base - altura + nivel * altura // 4
                    largura = altura // 3 - nivel * 5
                    topo_x = x + int(balanco * (1 - nivel * 0.22))
                    base_x = x + int(balanco * max(0, 0.55 - nivel * 0.18))
                    pygame.draw.polygon(tela, (15, 45 + nivel * 8, 38), [
                        (topo_x, y),
                        (base_x - largura, y + altura // 3),
                        (base_x + largura, y + altura // 3),
                    ])
        elif self.mundo == 1:
            for x, altura in self.decoracoes:
                x = self._posicao_cenario(x, 12)
                y = HORIZONTE - altura
                pygame.draw.line(tela, (90, 150, 120), (x, HORIZONTE + 4), (x, y), 2)
                pygame.draw.circle(tela, (110, 240, 170), (x, y), 3)
                pygame.draw.circle(tela, (120, 70, 170), (x + 9, y + 15), 2)
        elif self.mundo == 2:
            for x, altura in self.decoracoes:
                x = self._posicao_cenario(x, altura // 4 + 2)
                base = HORIZONTE + 2
                pygame.draw.polygon(tela, (100, 175, 220),
                                    [(x, base - altura), (x - altura // 4, base),
                                     (x + altura // 4, base)])
                pygame.draw.polygon(tela, (205, 245, 255),
                                    [(x, base - altura), (x, base - altura // 3),
                                     (x - altura // 8, base - altura // 5)])
        elif self.mundo == 3:
            for x, largura in self.decoracoes:
                x = self._posicao_cenario(x, largura * 5)
                pygame.draw.ellipse(tela, (90, 30, 20), (x - largura * 5, HORIZONTE + 12, largura * 10, 10))
                pygame.draw.ellipse(tela, (255, 90, 25), (x - largura * 4, HORIZONTE + 14, largura * 8, 4))
                pygame.draw.circle(tela, (100, 45, 35), (x, HORIZONTE - 95), largura * 4)
                pygame.draw.circle(tela, (145, 55, 35), (x, HORIZONTE - 95), largura * 4, 2)
        else:
            t = pygame.time.get_ticks() * 0.001
            for i, (x, y) in enumerate(self.decoracoes):
                x = self._posicao_cenario(x, 42)
                raio = 16 + i * 5
                pygame.draw.circle(tela, (95, 40, 140), (x, y), raio)
                pygame.draw.circle(tela, (195, 130, 255), (x, y), raio, 2)
                px = int(x + math.cos(t * (0.5 + i * 0.15)) * raio)
                py = int(y + math.sin(t * (0.5 + i * 0.15)) * raio * 0.45)
                pygame.draw.circle(tela, (230, 215, 255), (px, py), 2)

    def desenhar(self, tela):
        self.tempo += 1
        tela.blit(self.ceu, (0, 0))  # Céu escuro em degradê

        # Estrelas cintilando
        agora = pygame.time.get_ticks() * 0.003
        for ex, ey, tam, ph in self.estrelas:
            b = int(150 + 100 * math.sin(agora + ph))
            pygame.draw.circle(tela, (b, b, min(255, b + 20)), (ex, ey), tam)

        if self.mundo < 4:
            lua_cor = (225, 225, 240) if self.mundo != 3 else (255, 145, 95)
            brilho(tela, lua_cor, (650, 95), 110, 0.5)
            pygame.draw.circle(tela, lua_cor, (650, 95), 34)
            pygame.draw.circle(tela, (195, 195, 215), (640, 88), 7)
            pygame.draw.circle(tela, (195, 195, 215), (662, 104), 5)
            pygame.draw.circle(tela, (205, 205, 225), (655, 82), 4)

        # Nuvens à deriva
        for nx, ny, vel, surf in self.nuvens:
            px = (nx - self.tempo * vel) % (LARGURA + 240) - 240
            tela.blit(surf, (int(px), ny))

        # Montanhas com parallax (camadas se movem em velocidades diferentes)
        off_longe = int(self.tempo * 0.15) % LARGURA
        off_perto = int(self.tempo * 0.4) % LARGURA
        y_longe = HORIZONTE - self.montanhas_longe.get_height() + 25
        y_perto = HORIZONTE - self.montanhas_perto.get_height() + 12
        for off, surf, yy in ((off_longe, self.montanhas_longe, y_longe),
                              (off_perto, self.montanhas_perto, y_perto)):
            tela.blit(surf, (-off, yy))
            tela.blit(surf, (LARGURA - off, yy))

        # Neblina na base das montanhas
        tela.blit(self.neblina, (0, HORIZONTE - 60))

        # Chão
        tela.blit(self.chao, (0, HORIZONTE))
        pygame.draw.line(tela, (90, 190, 110), (0, HORIZONTE), (LARGURA, HORIZONTE), 3)

        # Piso em perspectiva: linhas horizontais mais espaçadas perto da câmera
        for off in (12, 30, 54, 84):
            pygame.draw.line(tela, (34, 88, 50), (0, HORIZONTE + off), (LARGURA, HORIZONTE + off), 1)
        desloc = (self.tempo * 1.0) % 100
        for i in range(-3, 12):
            xh = i * 100 - desloc
            xb = 400 + (xh - 400) * 1.9
            pygame.draw.line(tela, (30, 80, 46), (xh, HORIZONTE), (xb, ALTURA), 1)

        # Tufos de grama rolando
        for tx, ty, th, tv in self.tufos:
            px = int((tx - self.tempo * tv) % LARGURA)
            cor_tufo = ((50, 130, 72), (80, 145, 115), (130, 195, 220), (170, 75, 35), (120, 70, 155))[self.mundo]
            pygame.draw.line(tela, cor_tufo, (px, ty), (px - 3, ty - th), 2)
            pygame.draw.line(tela, tuple(min(255, c + 25) for c in cor_tufo), (px, ty), (px, ty - th - 2), 2)
            pygame.draw.line(tela, cor_tufo, (px, ty), (px + 3, ty - th), 2)

        self._desenhar_detalhes_mundo(tela)

        # Vagalumes
        t = pygame.time.get_ticks() * 0.001
        for vg in self.vagalumes:
            vx = vg[0] + math.sin(t * vg[3] + vg[2]) * 30
            vy = vg[1] + math.cos(t * vg[3] * 0.8 + vg[2]) * 14
            if math.sin(t * 2 * vg[3] + vg[2]) > -0.3:
                cor_luz = ((190, 255, 120), (110, 255, 190), (160, 220, 255),
                           (255, 130, 60), (220, 150, 255))[self.mundo]
                brilho(tela, cor_luz, (vx, vy), 9, 0.8)
                pygame.draw.circle(tela, tuple(min(255, c + 40) for c in cor_luz), (int(vx), int(vy)), 1)

# ==========================================
# LOOP PRINCIPAL DO JOGO
# ==========================================
async def main():
    conn = inicializar_db()
    relogio = pygame.time.Clock()

    jogador = Jogador("Jogador1")
    jogador.carregar_progresso(conn)

    fase = EsteticaFase()
    inimigos = []
    projetis = []
    projetis_boss = []
    misseis = []
    particulas = []
    textos = []
    tremor = 0   # frames restantes de tremor de tela
    flash = 0    # frames restantes de flash vermelho

    # Estados: "JOGANDO", "LOJA", "GAMEOVER" (fase falhou), "FASE_COMPLETA", "VITORIA"
    estado_jogo = "JOGANDO"
    abates_fase = 0          # inimigos comuns mortos na tentativa atual da fase
    boss_ativo = False
    aba_loja = "MELHORIAS"
    aviso_boss = 0           # frames do banner "BOSS: nome"
    moedas_ganhas = 0        # mostrado na tela de fase completa
    confirmar_limpeza_save = False
    fase.definir_fase(jogador.fase_atual)

    cursor_mao = False
    ultimo_save = 0   # ms do último salvamento por abate
    rodando = True
    while rodando:
        TELA.fill((0, 0, 0))
        mouse_pos = pygame.mouse.get_pos()
        sobre_clicavel = False

        # 1. TRATAMENTO DE EVENTOS
        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:
                jogador.salvar_progresso(conn)
                rodando = False

            # Teclado: Q / W / E acionam as habilidades durante a batalha
            if evento.type == pygame.KEYDOWN and estado_jogo == "JOGANDO" and evento.key in TECLAS_SKILLS:
                usar_habilidade(jogador, TECLAS_SKILLS[evento.key], inimigos, misseis, particulas, textos)
            if (evento.type == pygame.KEYDOWN and estado_jogo == "LOJA"
                    and confirmar_limpeza_save and evento.key == pygame.K_ESCAPE):
                confirmar_limpeza_save = False

            # Mouse: clique esquerdo
            if evento.type == pygame.MOUSEBUTTONDOWN and evento.button == 1:
                if estado_jogo == "JOGANDO":
                    if BOTAO_LOJA.collidepoint(evento.pos):
                        estado_jogo = "LOJA"
                    for chave, rect in RECT_SKILLS_HUD.items():
                        if rect.collidepoint(evento.pos):
                            usar_habilidade(jogador, chave, inimigos, misseis, particulas, textos)
                elif estado_jogo == "LOJA":
                    if confirmar_limpeza_save:
                        if BOTAO_CONFIRMAR_LIMPEZA.collidepoint(evento.pos):
                            jogador.limpar_progresso(conn)
                            reiniciar_partida(jogador, inimigos, projetis, projetis_boss,
                                              particulas, textos, misseis)
                            abates_fase = 0
                            boss_ativo = False
                            aviso_boss = 0
                            moedas_ganhas = 0
                            tremor = 0
                            flash = 0
                            fase.definir_fase(jogador.fase_atual)
                            aba_loja = "MELHORIAS"
                            confirmar_limpeza_save = False
                            estado_jogo = "JOGANDO"
                        elif BOTAO_CANCELAR_LIMPEZA.collidepoint(evento.pos):
                            confirmar_limpeza_save = False
                    elif BOTAO_LIMPAR_SAVE.collidepoint(evento.pos):
                        confirmar_limpeza_save = True
                    elif BOTAO_VOLTAR.collidepoint(evento.pos):
                        estado_jogo = "JOGANDO"
                    elif TAB_MELHORIAS.collidepoint(evento.pos):
                        aba_loja = "MELHORIAS"
                    elif TAB_HABILIDADES.collidepoint(evento.pos):
                        aba_loja = "HABILIDADES"
                    else:
                        for i, rect in enumerate(RECT_ITENS):
                            if rect.collidepoint(evento.pos):
                                if aba_loja == "MELHORIAS":
                                    comprou = comprar(jogador, i)
                                else:
                                    comprou = comprar_habilidade(jogador, ORDEM_SKILLS[i])
                                if comprou:
                                    jogador.salvar_progresso(conn)
                elif estado_jogo == "GAMEOVER" and BOTAO_RESTART.collidepoint(evento.pos):
                    # Refaz a fase atual do zero: só avança quem derrota o boss
                    reiniciar_partida(jogador, inimigos, projetis, projetis_boss, particulas, textos, misseis)
                    abates_fase = 0
                    boss_ativo = False
                    aviso_boss = 0
                    tremor = 0
                    flash = 0
                    estado_jogo = "JOGANDO"
                elif estado_jogo in ("FASE_COMPLETA", "VITORIA") and BOTAO_CONTINUAR.collidepoint(evento.pos):
                    reiniciar_partida(jogador, inimigos, projetis, projetis_boss, particulas, textos, misseis)
                    fase.definir_fase(jogador.fase_atual)
                    abates_fase = 0
                    boss_ativo = False
                    aviso_boss = 0
                    estado_jogo = "JOGANDO"

        if estado_jogo == "JOGANDO":
            fase.desenhar(TELA)

            # Spawn de inimigos (escalonados em x para não nascerem empilhados)
            fase_n = jogador.fase_atual
            if len(inimigos) == 0 and not boss_ativo:
                if abates_fase >= meta_abates(fase_n):
                    inimigos.append(BossFase(fase_n))
                    boss_ativo = True
                    aviso_boss = 170
                else:
                    for i in range(random.randint(1, 3)):
                        inimigos.append(Inimigo(25 + fase_n * 10, 10 + fase_n * 4, deslocamento_x=i * 70))

            for hab in jogador.habilidades.values():
                hab.atualizar()

            # Ataque Automático do Jogador
            jogador.timer_ataque += 1
            if jogador.timer_ataque >= jogador.cooldown_ataque and len(inimigos) > 0:
                projetis.append(Projetil(jogador.x + 40, jogador.y, jogador.ataque_base))
                jogador.timer_ataque = 0
                jogador.recuo = 5
                for _ in range(5):
                    particulas.append(Particula(jogador.x + 50, jogador.y + 20, (255, 210, 90),
                                                vx=random.uniform(1, 4), vy=random.uniform(-1.5, 1.5),
                                                vida=random.randint(8, 14), tam=2.5))

            # Tiro automático do boss
            for inimigo in inimigos:
                if isinstance(inimigo, BossFase) and inimigo.vivo:
                    inimigo.timer_tiro += 1
                    if inimigo.timer_tiro >= inimigo.INTERVALO_TIRO:
                        projetis_boss.extend(inimigo.disparar(jogador))
                        inimigo.timer_tiro = 0
                    projetis_boss.extend(inimigo.continuar_rajada(jogador))

            # Atualizar e verificar os tiros do boss
            for projetil in projetis_boss[:]:
                projetil.atualizar()
                if not projetil.ativo:
                    projetis_boss.remove(projetil)
                    continue
                projetil.desenhar(TELA)
                if (jogador.x <= projetil.x <= jogador.x + jogador.LARGURA_CORPO
                        and jogador.y <= projetil.y <= jogador.y + jogador.ALTURA_CORPO):
                    jogador.receber_dano(projetil.dano)
                    projetil.ativo = False
                    projetis_boss.remove(projetil)
                    tremor = 12
                    flash = 10
                    textos.append(TextoFlutuante(
                        f"-{projetil.dano}", (255, 90, 90), jogador.x + 20, jogador.y - 34
                    ))

            # Habilidade: laser constante (dano contínuo em todos os inimigos)
            laser = jogador.habilidades["laser"]
            if laser.ativa > 0:
                desenhar_laser(TELA, jogador.x + 44, jogador.y + 20, laser.ativa)
                if laser.ativa % 15 == 0:   # 4 ticks por segundo
                    dano_tick = LASER_DANO_POR_SEG * 15 / FPS
                    for alvo in inimigos:
                        if alvo.vivo and alvo.x < LARGURA:
                            alvo.receber_dano(dano_tick)
                            textos.append(TextoFlutuante(f"{dano_tick:g}", (140, 230, 255),
                                                         alvo.x + alvo.LARGURA_CORPO / 2, alvo.y - 26))

            # Habilidade: míssil (explode em área ao tocar o primeiro inimigo)
            for m in misseis[:]:
                m.atualizar()
                alvo_hit = next((a for a in inimigos if a.vivo and a.x < m.x < a.x + a.LARGURA_CORPO + 10), None)
                if alvo_hit is not None:
                    m.ativo = False
                    ex, ey = m.x, m.y
                    for _ in range(36):
                        particulas.append(Particula(ex, ey, random.choice(((255, 150, 50), (255, 220, 90), (255, 90, 40))),
                                                    vida=random.randint(18, 34), tam=4))
                    for alvo in inimigos:
                        if alvo.vivo and abs((alvo.x + alvo.LARGURA_CORPO / 2) - ex) <= Missil.RAIO_EXPLOSAO:
                            alvo.receber_dano(m.dano)
                            textos.append(TextoFlutuante(str(m.dano), (255, 170, 70),
                                                         alvo.x + alvo.LARGURA_CORPO / 2, alvo.y - 30))
                    tremor = max(tremor, 10)
                if not m.ativo:
                    misseis.remove(m)
                else:
                    m.desenhar(TELA)

            # Atualizar e Desenhar Projéteis
            for p in projetis[:]:
                p.atualizar()
                if not p.ativo:
                    projetis.remove(p)
                    continue
                p.desenhar(TELA)

            # Atualizar e Desenhar Inimigos
            for inimigo in inimigos[:]:
                inimigo.atualizar()
                inimigo.desenhar(TELA)

                # Colisão Projétil -> Inimigo
                for p in projetis:
                    if p.ativo and inimigo.x < p.x < inimigo.x + inimigo.LARGURA_CORPO + 10:
                        inimigo.receber_dano(p.dano)
                        p.ativo = False
                        for _ in range(6):
                            particulas.append(Particula(p.x, p.y, (255, 200, 80), vx=random.uniform(-4, 1),
                                                        vy=random.uniform(-3, 2), vida=random.randint(10, 20), tam=3))
                        textos.append(TextoFlutuante(str(p.dano), (255, 235, 140), inimigo.x + inimigo.LARGURA_CORPO / 2,
                                                     inimigo.y - 26))

                # Colisão Inimigo -> Jogador
                if inimigo.vivo and inimigo.x <= jogador.x + 40:
                    if isinstance(inimigo, Boss):
                        # Boss que alcança o jogador não conta como derrotado: a fase falha
                        dano_colisao = jogador.vida
                        jogador.receber_dano(jogador.vida_max)
                    else:
                        dano_colisao = 10
                        jogador.receber_dano(dano_colisao)
                        inimigo.vivo = False # Monstro explode ao bater no jogador
                    tremor = 12
                    flash = 10
                    textos.append(TextoFlutuante(
                        f"-{dano_colisao}", (255, 90, 90), jogador.x + 20, jogador.y - 34
                    ))

                if not inimigo.vivo:
                    inimigos.remove(inimigo)
                    jogador.abates += 1
                    jogador.dinheiro += inimigo.recompensa
                    if not isinstance(inimigo, Boss):
                        abates_fase += 1
                    agora = pygame.time.get_ticks()
                    if agora - ultimo_save > 3000:
                        jogador.salvar_progresso(conn)
                        ultimo_save = agora
                    cx = inimigo.x + inimigo.LARGURA_CORPO / 2
                    cy = inimigo.y + inimigo.ALTURA_CORPO / 2
                    qtd = 40 if isinstance(inimigo, Boss) else 14
                    for _ in range(qtd):
                        particulas.append(Particula(cx, cy, inimigo.cor))
                    for _ in range(qtd // 2):
                        particulas.append(Particula(cx, cy, (255, 215, 70)))
                    textos.append(TextoFlutuante(f"+{inimigo.recompensa}", (255, 215, 60), cx, inimigo.y - 24))
                    if isinstance(inimigo, Boss):
                        tremor = 20
                        primeira_vez = fase_n == jogador.fase_concluida + 1
                        moedas_ganhas = 0
                        if primeira_vez:
                            moedas_ganhas = 1 + (1 if fase_n % 5 == 0 else 0)   # bônus nos bosses 5, 10, 15, 20
                            jogador.fase_concluida = fase_n
                            jogador.moedas += moedas_ganhas
                        jogador.salvar_progresso(conn)
                        misseis.clear()
                        laser.ativa = 0
                        estado_jogo = "VITORIA" if fase_n == TOTAL_FASES else "FASE_COMPLETA"
                        break

            if not any(isinstance(inimigo, Boss) and inimigo.vivo for inimigo in inimigos):
                projetis_boss.clear()

            jogador.desenhar(TELA)

            # Partículas e textos
            for pt in particulas[:]:
                pt.atualizar()
                if pt.vida <= 0 or pt.y > ALTURA:
                    particulas.remove(pt)
                else:
                    pt.desenhar(TELA)
            for tx in textos[:]:
                tx.atualizar()
                if tx.vida <= 0:
                    textos.remove(tx)
                else:
                    tx.desenhar(TELA)

            if not jogador.vivo and estado_jogo == "JOGANDO":
                estado_jogo = "GAMEOVER"
                jogador.salvar_progresso(conn)

            # Tremor de tela
            if tremor > 0:
                BUFFER_TREMOR.blit(TELA, (0, 0))
                copia = BUFFER_TREMOR
                TELA.fill((0, 0, 0))
                amp = 1 + tremor // 4
                TELA.blit(copia, (random.randint(-amp, amp), random.randint(-amp, amp)))
                tremor -= 1

            # Vinheta para dar clima
            TELA.blit(VINHETA, (0, 0))

            # Flash vermelho ao levar dano
            if flash > 0:
                FLASH_DANO.set_alpha(flash * 8)
                TELA.blit(FLASH_DANO, (0, 0))
                flash -= 1

            # HUD
            painel(TELA, (10, 10, 380, 92))
            pygame.draw.circle(TELA, (255, 200, 40), (28, 28), 8)
            pygame.draw.circle(TELA, (255, 240, 130), (26, 26), 3)
            texto_sombra(TELA, FONTE, f"Ouro: {jogador.dinheiro}", (255, 255, 255), (44, 17))
            desenhar_moeda_especial(TELA, 176, 28, 8)
            texto_sombra(TELA, FONTE, f"{jogador.moedas}", (230, 190, 255), (190, 17))
            texto_sombra(TELA, FONTE, f"FASE {fase_n}/{TOTAL_FASES}", (255, 255, 255), (262, 17))

            barra(TELA, 20, 46, 250, 14, jogador.vida / jogador.vida_max, (60, 220, 90))
            hp_txt = FONTE_PEQ.render(f"HP {jogador.vida}/{jogador.vida_max}", True, (255, 255, 255))
            TELA.blit(hp_txt, (278, 47))

            if boss_ativo and any(isinstance(i, Boss) for i in inimigos):
                boss_txt = FONTE_PEQ.render("BOSS!", True, (230, 150, 255))
                barra(TELA, 20, 68, 250, 8, 1, (200, 60, 255), fundo=(40, 10, 50))
            else:
                faltam = max(0, meta_abates(fase_n) - abates_fase)
                progresso = 1 - faltam / meta_abates(fase_n)
                boss_txt = FONTE_PEQ.render(f"Boss em {faltam}", True, (200, 170, 230))
                barra(TELA, 20, 68, 250, 8, progresso, (170, 80, 230), fundo=(40, 10, 50))
            TELA.blit(boss_txt, (278, 66))

            # Botão clicável da loja
            sobre_clicavel = botao(TELA, BOTAO_LOJA, "Loja", mouse_pos)

            # Habilidades (Q / W / E ou clique)
            for chave, rect in RECT_SKILLS_HUD.items():
                if desenhar_botao_habilidade(TELA, rect, jogador.habilidades[chave], mouse_pos):
                    sobre_clicavel = True

            # Banner de boss
            if aviso_boss > 0:
                aviso_boss -= 1
                alfa = min(1, aviso_boss / 40)
                nome_boss = next((i.nome for i in inimigos if isinstance(i, BossFase)), "")
                banner = FONTE_TITULO.render(f"BOSS: {nome_boss.upper()}", True, (255, 120, 150))
                sombra_b = FONTE_TITULO.render(f"BOSS: {nome_boss.upper()}", True, (0, 0, 0))
                banner.set_alpha(int(255 * alfa))
                sombra_b.set_alpha(int(255 * alfa))
                TELA.blit(sombra_b, sombra_b.get_rect(center=(LARGURA // 2 + 2, 142)))
                TELA.blit(banner, banner.get_rect(center=(LARGURA // 2, 140)))

        elif estado_jogo == "LOJA":
            sobre_clicavel = desenhar_loja(TELA, jogador, aba_loja, mouse_pos)
            if confirmar_limpeza_save:
                sobre_clicavel = desenhar_confirmacao_limpeza(TELA, mouse_pos) or sobre_clicavel

        elif estado_jogo in ("FASE_COMPLETA", "VITORIA"):
            sobre_clicavel = desenhar_resultado(
                TELA, jogador.fase_concluida, moedas_ganhas, estado_jogo == "VITORIA", mouse_pos
            )

        elif estado_jogo == "GAMEOVER":
            TELA.blit(FUNDO_GAMEOVER, (0, 0))
            TELA.blit(VINHETA, (0, 0))
            painel(TELA, (200, 215, 400, 230), cor=(30, 0, 0), alpha=190, borda=(255, 90, 90), raio=14)
            texto_sombra(TELA, FONTE_TITULO, "GAME OVER", (255, 255, 255), (300, 235), centro_x=True)
            texto_sombra(TELA, FONTE, f"Abates Finais: {jogador.abates}", (255, 220, 220), (320, 300), centro_x=True)
            texto_sombra(TELA, FONTE_PEQ, f"Derrote o boss da fase {jogador.fase_atual} para avançar.",
                         (255, 190, 190), (0, 338), centro_x=True)
            if botao(TELA, BOTAO_RESTART, "TENTAR NOVAMENTE", mouse_pos, cor=(100, 255, 140)):
                sobre_clicavel = True

        if sobre_clicavel != cursor_mao:
            cursor_mao = sobre_clicavel
            try:
                pygame.mouse.set_cursor(pygame.SYSTEM_CURSOR_HAND if cursor_mao else pygame.SYSTEM_CURSOR_ARROW)
            except Exception:
                pass

        pygame.display.flip()
        relogio.tick(FPS)
        await asyncio.sleep(0)

    pygame.quit()
    if sys.platform != "emscripten":
        conn.close()

if __name__ == "__main__":
    asyncio.run(main())