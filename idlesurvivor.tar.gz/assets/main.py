import asyncio
import json
import pygame
import math
import random
import os
import sys

if sys.platform != "emscripten":
    import sqlite3

# Inicialização do Pygame
pygame.init()
LARGURA, ALTURA = 800, 600
TELA = pygame.display.set_mode((LARGURA, ALTURA))
if sys.platform == "emscripten":
    import platform
    platform.window.canvas.style.imageRendering = "pixelated"
    estilo_fundo = platform.window.document.body.style
    estilo_fundo.background = "#10091b"
    estilo_fundo.backgroundImage = 'url("game-background.svg")'
    estilo_fundo.backgroundSize = "cover"
    estilo_fundo.backgroundPosition = "center"
    estilo_fundo.backgroundRepeat = "no-repeat"
pygame.display.set_caption("Idle Survivor")
DIRETORIO_BASE = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
CAMINHO_FONTE = os.path.join(DIRETORIO_BASE, "assets", "VT323-Regular.ttf")
FONTE = pygame.font.Font(CAMINHO_FONTE, 20)
FONTE_TITULO = pygame.font.Font(CAMINHO_FONTE, 36)
FONTE_TITULO.set_bold(True)
FONTE_PEQ = pygame.font.Font(CAMINHO_FONTE, 12)
FONTE_PEQ.set_bold(True)
FONTE_NUM = pygame.font.Font(CAMINHO_FONTE, 16)
FONTE_NUM.set_bold(True)
FPS = 60

# Layout vertical: o horizonte é onde começa o chão; PE_Y é a linha onde
# jogador e inimigos apoiam os pés (dentro da faixa de chão).
HORIZONTE = ALTURA - 100
PE_Y = ALTURA - 52

# ==========================================
# AUXILIARES VISUAIS (apenas desenho)
# ==========================================
_CACHE_BRILHO = {}
_CACHE_SOMBRA = {}

def gradiente_vertical(largura, altura, topo, base):
    surf = pygame.Surface((largura, altura))
    for y in range(altura):
        t = y / max(1, altura - 1)
        cor = tuple(int(topo[i] + (base[i] - topo[i]) * t) for i in range(3))
        pygame.draw.line(surf, cor, (0, y), (largura, y))
    return surf

def brilho(tela, cor, centro, raio, intensidade=0.9):
    """Halo de luz aditivo (cacheado; intensidade quantizada para o cache não crescer)."""
    intensidade = round(intensidade * 20) / 20
    chave = (cor, raio, intensidade)
    surf = _CACHE_BRILHO.get(chave)
    if surf is None:
        surf = pygame.Surface((raio * 2, raio * 2))
        for r in range(raio, 0, -2):
            f = intensidade * (1 - r / raio) ** 2
            pygame.draw.circle(surf, (int(cor[0] * f), int(cor[1] * f), int(cor[2] * f)), (raio, raio), r)
        _CACHE_BRILHO[chave] = surf
    tela.blit(surf, (int(centro[0] - raio), int(centro[1] - raio)), special_flags=pygame.BLEND_RGB_ADD)

def sombra_chao(tela, cx, pes_y, largura, alpha=110):
    """Elipse escura centrada nos pés da entidade."""
    largura = max(6, int(largura))
    chave = (largura, alpha)
    surf = _CACHE_SOMBRA.get(chave)
    if surf is None:
        surf = pygame.Surface((largura, 12), pygame.SRCALPHA)
        pygame.draw.ellipse(surf, (0, 0, 0, alpha), (0, 0, largura, 12))
        pygame.draw.ellipse(surf, (0, 0, 0, alpha // 2), (largura // 5, 2, largura * 3 // 5, 8))
        _CACHE_SOMBRA[chave] = surf
    tela.blit(surf, (int(cx - largura / 2), int(pes_y - 6)))

def painel(tela, rect, cor=(10, 10, 25), alpha=170, borda=(90, 90, 150), raio=10):
    x, y, w, h = rect
    surf = pygame.Surface((w, h), pygame.SRCALPHA)
    pygame.draw.rect(surf, (*cor, alpha), (0, 0, w, h), border_radius=raio)
    pygame.draw.rect(surf, (*borda, 255), (0, 0, w, h), 2, border_radius=raio)
    tela.blit(surf, (x, y))

def barra(tela, x, y, w, h, fracao, cor, fundo=(50, 15, 15), borda=(0, 0, 0)):
    fracao = max(0, min(1, fracao))
    pygame.draw.rect(tela, fundo, (x, y, w, h), border_radius=3)
    if fracao > 0:
        pygame.draw.rect(tela, cor, (x, y, max(2, int(w * fracao)), h), border_radius=3)
        # reflexo no topo da barra
        clara = tuple(min(255, c + 70) for c in cor)
        pygame.draw.rect(tela, clara, (x + 1, y + 1, max(1, int(w * fracao) - 2), max(1, h // 3)), border_radius=2)
    pygame.draw.rect(tela, borda, (x, y, w, h), 1, border_radius=3)

def texto_sombra(tela, fonte, texto, cor, pos, centro_x=False):
    sombra = fonte.render(texto, True, (0, 0, 0))
    principal = fonte.render(texto, True, cor)
    x, y = pos
    if centro_x:
        x = LARGURA // 2 - principal.get_width() // 2
    tela.blit(sombra, (x + 2, y + 2))
    tela.blit(principal, (x, y))

def criar_vinheta():
    surf = pygame.Surface((LARGURA, ALTURA), pygame.SRCALPHA)
    passos = 70
    for i in range(passos):
        a = int(140 * (1 - i / passos) ** 2)
        pygame.draw.rect(surf, (0, 0, 0, a), (i, i, LARGURA - 2 * i, ALTURA - 2 * i), 1)
    return surf

def botao(tela, rect, texto, mouse_pos, cor=(255, 215, 0), fonte=None):
    """Botão clicável com efeito hover. Retorna True se o mouse está sobre ele."""
    fonte = fonte or FONTE
    sobre = rect.collidepoint(mouse_pos)
    fundo = (50, 45, 100) if sobre else (20, 20, 50)
    borda = cor if sobre else tuple(c // 2 for c in cor)
    painel(tela, tuple(rect), cor=fundo, alpha=230, borda=borda)
    txt = fonte.render(texto, True, cor if sobre else (220, 220, 235))
    tela.blit(txt, txt.get_rect(center=rect.center))
    return sobre

# Áreas clicáveis da interface
BOTAO_LOJA = pygame.Rect(LARGURA - 140, 10, 130, 40)     # no HUD durante a batalha
BOTAO_VOLTAR = pygame.Rect(LARGURA // 2 - 100, 520, 200, 44)  # dentro da loja
BOTAO_RESTART = pygame.Rect(LARGURA // 2 - 100, 375, 200, 46)
RECT_ITENS = [pygame.Rect(100, yy, 600, 76) for yy in (140, 230, 320)]

def comprar(jogador, indice):
    """0 = Ataque, 1 = Vel. Ataque, 2 = Vida. Retorna True se a compra foi feita."""
    niveis = (jogador.nivel_ataque, jogador.nivel_vel_ataque, jogador.nivel_vida)
    custo = niveis[indice] * 50
    if jogador.dinheiro < custo:
        return False
    jogador.dinheiro -= custo
    if indice == 0:
        jogador.nivel_ataque += 1
    elif indice == 1:
        jogador.nivel_vel_ataque += 1
    else:
        jogador.nivel_vida += 1
    jogador.atualizar_status()
    return True

def reiniciar_partida(jogador, inimigos, projetis, projetis_boss, particulas, textos):
    jogador._vida = jogador.vida_max
    jogador.vivo = True
    jogador.timer_ataque = 0
    jogador.recuo = 0
    inimigos.clear()
    projetis.clear()
    projetis_boss.clear()
    particulas.clear()
    textos.clear()

def calcular_proximo_boss(abates, intervalo):
    return max(intervalo, ((abates - 1) // intervalo + 1) * intervalo)

FUNDO_LOJA = gradiente_vertical(LARGURA, ALTURA, (28, 22, 60), (12, 12, 28))
FUNDO_GAMEOVER = gradiente_vertical(LARGURA, ALTURA, (120, 10, 10), (30, 0, 0))
VINHETA = criar_vinheta()
FLASH_DANO = pygame.Surface((LARGURA, ALTURA))
FLASH_DANO.fill((255, 30, 30))

# ==========================================
# PERSISTÊNCIA DE DADOS (BANCO DE DADOS)
# ==========================================
def inicializar_db():
    if sys.platform == "emscripten":
        import platform
        return platform.window.localStorage

    conn = sqlite3.connect("save_idle.db")
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS jogador (
            nome TEXT PRIMARY KEY,
            dinheiro INTEGER,
            nivel_ataque INTEGER,
            nivel_vel_ataque INTEGER,
            nivel_vida INTEGER,
            abates INTEGER
        )
    ''')
    conn.commit()
    return conn

# ==========================================
# CLASSES (PARADIGMA ORIENTADO A OBJETOS)
# ==========================================

# 1. Classe Base e Encapsulamento
class Entidade:
    ALTURA_CORPO = 40
    LARGURA_CORPO = 40

    def __init__(self, x, y, vida_max, cor):
        self.x = x
        self.y = y
        self._vida = vida_max  # Encapsulamento: Vida protegida
        self.vida_max = vida_max
        self.cor = cor
        self.vivo = True

    @property
    def vida(self):
        return self._vida

    def receber_dano(self, dano):
        self._vida -= dano
        if self._vida <= 0:
            self._vida = 0
            self.vivo = False

    def desenhar(self, tela):
        pass # A ser implementado pelas subclasses

# 2. Herança e Polimorfismo
class Jogador(Entidade):
    ALTURA_CORPO = 40
    LARGURA_CORPO = 40

    def __init__(self, nome):
        # y é o topo do corpo: os pés ficam exatamente em PE_Y
        super().__init__(110, PE_Y - self.ALTURA_CORPO, 100, (0, 255, 255)) # Ciano Neon
        self.nome = nome
        self.dinheiro = 0
        self.abates = 0
        self.nivel_ataque = 1
        self.nivel_vel_ataque = 1
        self.nivel_vida = 1

        # Status derivados dos níveis
        self.ataque_base = 10
        self.cooldown_ataque = 60 # Em frames (1 seg)
        self.timer_ataque = 0
        self.recuo = 0 # animação do canhão ao atirar

    def carregar_progresso(self, conn):
        if sys.platform == "emscripten":
            dados = conn.getItem(self.nome)
            if dados is not None:
                progresso = json.loads(str(dados))
                self.dinheiro = progresso["dinheiro"]
                self.nivel_ataque = progresso["nivel_ataque"]
                self.nivel_vel_ataque = progresso["nivel_vel_ataque"]
                self.nivel_vida = progresso["nivel_vida"]
                self.abates = progresso["abates"]
                self.atualizar_status()
            else:
                self.salvar_progresso(conn)
            return

        cursor = conn.cursor()
        cursor.execute("SELECT * FROM jogador WHERE nome=?", (self.nome,))
        row = cursor.fetchone()
        if row:
            self.dinheiro, self.nivel_ataque, self.nivel_vel_ataque, self.nivel_vida, self.abates = row[1], row[2], row[3], row[4], row[5]
            self.atualizar_status()
        else:
            self.salvar_progresso(conn)

    def salvar_progresso(self, conn):
        if sys.platform == "emscripten":
            progresso = {
                "dinheiro": self.dinheiro,
                "nivel_ataque": self.nivel_ataque,
                "nivel_vel_ataque": self.nivel_vel_ataque,
                "nivel_vida": self.nivel_vida,
                "abates": self.abates,
            }
            conn.setItem(self.nome, json.dumps(progresso))
            return

        cursor = conn.cursor()
        cursor.execute('''
            INSERT OR REPLACE INTO jogador (nome, dinheiro, nivel_ataque, nivel_vel_ataque, nivel_vida, abates)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (self.nome, self.dinheiro, self.nivel_ataque, self.nivel_vel_ataque, self.nivel_vida, self.abates))
        conn.commit()

    def atualizar_status(self):
        self.ataque_base = 10 + (self.nivel_ataque * 5)
        self.cooldown_ataque = max(10, 60 - (self.nivel_vel_ataque * 5))
        self.vida_max = 100 + (self.nivel_vida * 20)
        self._vida = self.vida_max

    # Sobrescrita visual
    def desenhar(self, tela):
        agora = pygame.time.get_ticks()
        respiro = int(1 + math.sin(agora * 0.006))  # 0..2 px (idle)
        x = int(self.x)
        y = int(self.y) - respiro
        pes = int(self.y) + self.ALTURA_CORPO

        pulso = 0.75 + 0.25 * math.sin(agora * 0.006)
        brilho(tela, self.cor, (x + 20, y + 22), 55, 0.5 * pulso)

        # Sombra e brilho projetado no chão
        sombra_chao(tela, x + 20, pes, 50 - respiro * 3)
        brilho(tela, (0, 120, 130), (x + 20, pes), 34, 0.35 * pulso)

        # Canhão frontal (com recuo)
        cx = x - int(self.recuo)
        pygame.draw.rect(tela, (70, 90, 110), (cx + 34, y + 16, 14, 8), border_radius=3)
        pygame.draw.rect(tela, (150, 220, 255), (cx + 44, y + 17, 4, 6), border_radius=2)
        if self.recuo > 2:
            brilho(tela, (255, 220, 120), (cx + 50, y + 20), 18, 0.9)
        self.recuo = max(0, self.recuo - 0.6)

        # Corpo: contorno escuro + corpo + brilho interno
        pygame.draw.rect(tela, (0, 110, 120), (x, y, 40, 40), border_radius=8)
        pygame.draw.rect(tela, self.cor, (x + 2, y + 2, 36, 36), border_radius=7)
        pygame.draw.rect(tela, (170, 255, 255), (x + 5, y + 4, 30, 8), border_radius=5)

        # Botas (apoiadas no chão)
        pygame.draw.rect(tela, (0, 70, 85), (x + 4, y + 34, 13, 8), border_radius=3)
        pygame.draw.rect(tela, (0, 70, 85), (x + 23, y + 34, 13, 8), border_radius=3)
        pygame.draw.rect(tela, (60, 190, 200), (x + 4, y + 34, 13, 3), border_radius=2)
        pygame.draw.rect(tela, (60, 190, 200), (x + 23, y + 34, 13, 3), border_radius=2)

        # Visor
        pygame.draw.rect(tela, (10, 20, 40), (x + 18, y + 14, 18, 12), border_radius=4)
        pygame.draw.rect(tela, (120, 255, 200), (x + 26, y + 17, 7, 6), border_radius=2)
        pygame.draw.rect(tela, (255, 255, 255), (x + 27, y + 18, 2, 2))

        # Antena
        pygame.draw.line(tela, (150, 220, 255), (x + 8, y + 2), (x + 8, y - 6), 2)
        brilho(tela, (255, 80, 80), (x + 8, y - 6), 8, 0.4 + 0.5 * max(0, math.sin(agora * 0.01)))
        pygame.draw.circle(tela, (255, 90, 90), (x + 8, y - 6), 2)

        # Barra de Vida
        barra(tela, x - 2, y - 20, 44, 7, self._vida / self.vida_max, (60, 220, 90))

class Inimigo(Entidade):
    ALTURA_CORPO = 30
    LARGURA_CORPO = 30

    def __init__(self, hp_base, recompensa, deslocamento_x=0):
        # y é o topo do corpo: os pés ficam exatamente em PE_Y
        super().__init__(LARGURA + 50 + deslocamento_x, PE_Y - self.ALTURA_CORPO, hp_base, (255, 50, 50))
        self.velocidade = 2
        self.recompensa = recompensa
        self.fase = random.random() * 6.28  # defasagem do pulinho

    def atualizar(self):
        self.x -= self.velocidade

    def desenhar(self, tela):
        agora = pygame.time.get_ticks()
        salto = abs(math.sin(agora * 0.008 + self.fase)) * 8
        x = int(self.x)
        y = int(self.y - salto)
        pes = int(self.y) + self.ALTURA_CORPO

        brilho(tela, self.cor, (x + 15, y + 15), 38, 0.45)

        # Sombra (encolhe quando o inimigo pula)
        sombra_chao(tela, x + 15, pes, 34 - salto * 1.5)

        # Espinhos
        for i in range(3):
            pygame.draw.polygon(tela, (150, 20, 20),
                                [(x + 4 + i * 10, y), (x + 9 + i * 10, y - 7), (x + 14 + i * 10, y)])

        # Pezinhos
        pygame.draw.rect(tela, (90, 10, 10), (x + 3, y + 26, 10, 6), border_radius=2)
        pygame.draw.rect(tela, (90, 10, 10), (x + 17, y + 26, 10, 6), border_radius=2)

        # Corpo
        pygame.draw.rect(tela, (120, 15, 15), (x, y, 30, 30), border_radius=5)
        pygame.draw.rect(tela, self.cor, (x + 2, y + 2, 26, 26), border_radius=4)
        pygame.draw.rect(tela, (255, 130, 130), (x + 4, y + 4, 22, 5), border_radius=3)

        # Olhos zangados olhando para a esquerda
        for ox in (6, 17):
            pygame.draw.rect(tela, (255, 255, 230), (x + ox, y + 11, 8, 8), border_radius=2)
            pygame.draw.rect(tela, (30, 0, 0), (x + ox, y + 13, 4, 5))
            pygame.draw.line(tela, (80, 0, 0), (x + ox - 1, y + 9), (x + ox + 8, y + 12), 2)

        # Boca
        pygame.draw.rect(tela, (60, 0, 0), (x + 7, y + 22, 16, 4), border_radius=2)

        # Barra de vida (só aparece se ferido)
        if self._vida < self.vida_max:
            barra(tela, x, y - 16, 30, 5, self._vida / self.vida_max, (255, 200, 60))

class Boss(Inimigo):
    ALTURA_CORPO = 50
    LARGURA_CORPO = 50
    DANO_COLISAO = 100
    DANO_TIRO = 20
    INTERVALO_TIRO = 120

    def __init__(self, hp_base, recompensa):
        # Herda Inimigo mas muda propriedades (Polimorfismo estrutural)
        super().__init__(hp_base * 5, recompensa * 10)
        self.cor = (148, 0, 211) # Roxo
        self.velocidade = 1
        self.timer_tiro = 0

    def desenhar(self, tela):
        agora = pygame.time.get_ticks()
        flutua = (math.sin(agora * 0.004 + self.fase) + 1) * 3  # paira 0..6 px
        x = int(self.x)
        y = int(self.y - flutua)
        pes = int(self.y) + self.ALTURA_CORPO

        pulso = 0.7 + 0.3 * math.sin(agora * 0.008)
        brilho(tela, self.cor, (x + 25, y + 30), 80, 0.7 * pulso)

        # Sombra e reflexo no chão
        sombra_chao(tela, x + 25, pes, 62 - flutua * 2, alpha=120)
        brilho(tela, (90, 0, 140), (x + 25, pes), 44, 0.4 * pulso)

        pontos = [(x + 25, y), (x + 50, y + 50), (x, y + 50)]
        pygame.draw.polygon(tela, (70, 0, 110), pontos)
        interno = [(x + 25, y + 8), (x + 43, y + 46), (x + 7, y + 46)]
        pygame.draw.polygon(tela, self.cor, interno)
        pygame.draw.polygon(tela, (230, 150, 255), pontos, 2)

        # Olho central
        pygame.draw.circle(tela, (255, 240, 120), (x + 25, y + 32), 8)
        pygame.draw.circle(tela, (20, 0, 30), (x + 22, y + 32), 4)
        brilho(tela, (255, 220, 80), (x + 25, y + 32), 16, 0.8)

        # Barra de Vida do Boss
        barra(tela, x, y - 16, 50, 8, self._vida / self.vida_max, (200, 60, 255), fundo=(40, 10, 50))

class Projetil:
    def __init__(self, x, y, dano):
        self.x = x
        self.y = y + 20
        self.dano = dano
        self.velocidade = 10
        self.ativo = True

    def atualizar(self):
        self.x += self.velocidade
        if self.x > LARGURA:
            self.ativo = False

    def desenhar(self, tela):
        px, py = int(self.x), int(self.y)
        # Rastro de luz
        for i in range(1, 6):
            r = max(1, 5 - i)
            cor = (255, 200 - i * 25, 40)
            pygame.draw.circle(tela, cor, (px - i * 6, py), r)
        brilho(tela, (255, 220, 60), (px, py), 20, 0.9)
        pygame.draw.circle(tela, (255, 180, 0), (px, py), 5)
        pygame.draw.circle(tela, (255, 255, 220), (px, py), 3)

class ProjetilBoss:
    def __init__(self, x, y, dano):
        self.x = x
        self.y = y
        self.dano = dano
        self.velocidade = 8
        self.ativo = True

    def atualizar(self):
        self.x -= self.velocidade
        if self.x < 0:
            self.ativo = False

    def desenhar(self, tela):
        px, py = int(self.x), int(self.y)
        brilho(tela, (210, 80, 255), (px, py), 18, 0.8)
        pygame.draw.circle(tela, (190, 40, 255), (px, py), 6)
        pygame.draw.circle(tela, (245, 200, 255), (px, py), 3)

class Particula:
    """Faísca de impacto / explosão."""
    def __init__(self, x, y, cor, vx=None, vy=None, vida=None, tam=None):
        ang = random.uniform(0, 6.283)
        vel = random.uniform(1, 5)
        self.x, self.y = x, y
        self.vx = vx if vx is not None else math.cos(ang) * vel
        self.vy = vy if vy is not None else math.sin(ang) * vel - 1.5
        self.vida = self.vida_max = vida or random.randint(20, 40)
        self.tam = tam or random.uniform(2, 4)
        self.cor = cor

    def atualizar(self):
        self.x += self.vx
        self.y += self.vy
        self.vy += 0.15
        self.vida -= 1

    def desenhar(self, tela):
        f = max(0, self.vida / self.vida_max)
        r = max(1, int(self.tam * f + 0.5))
        cor = (int(self.cor[0] * (0.4 + 0.6 * f)), int(self.cor[1] * (0.4 + 0.6 * f)), int(self.cor[2] * (0.4 + 0.6 * f)))
        pygame.draw.circle(tela, cor, (int(self.x), int(self.y)), r)

class TextoFlutuante:
    """Número de dano / ouro que sobe e some."""
    def __init__(self, texto, cor, x, y):
        self.surf = FONTE_NUM.render(texto, True, cor)
        self.sombra = FONTE_NUM.render(texto, True, (0, 0, 0))
        self.x, self.y = x - self.surf.get_width() / 2, y
        self.vida = self.vida_max = 50

    def atualizar(self):
        self.y -= 0.8
        self.vida -= 1

    def desenhar(self, tela):
        alpha = int(255 * min(1, self.vida / (self.vida_max * 0.5)))
        self.surf.set_alpha(alpha)
        self.sombra.set_alpha(alpha)
        tela.blit(self.sombra, (int(self.x) + 1, int(self.y) + 1))
        tela.blit(self.surf, (int(self.x), int(self.y)))

class EsteticaFase:
    def __init__(self):
        self.tempo = 0
        self.ceu = gradiente_vertical(LARGURA, ALTURA, (6, 6, 24), (62, 30, 74))
        self.chao = gradiente_vertical(LARGURA, ALTURA - HORIZONTE, (30, 70, 42), (6, 18, 14))
        self.neblina = self._criar_neblina()
        rng = random.Random(7)  # gerador próprio: não interfere no random do jogo
        self.estrelas = [(rng.randint(0, LARGURA), rng.randint(0, HORIZONTE - 140),
                          rng.choice((1, 1, 2)), rng.random() * 6.28) for _ in range(90)]
        self.montanhas_longe = self._criar_montanhas((34, 30, 66), 150, (2, 5, 9), 11)
        self.montanhas_perto = self._criar_montanhas((20, 26, 42), 95, (3, 6, 8), 29)
        self.nuvens = [(rng.randint(0, LARGURA), rng.randint(70, 250), rng.uniform(0.12, 0.35),
                        self._criar_nuvem(rng)) for _ in range(5)]
        self.vagalumes = [[rng.random() * LARGURA, rng.uniform(HORIZONTE - 70, ALTURA - 25),
                           rng.random() * 6.28, rng.uniform(0.5, 1.4)] for _ in range(16)]
        # tufos de grama: (x, y, altura, velocidade) — mais perto da câmera = mais rápido
        self.tufos = []
        for _ in range(46):
            ty = rng.randint(HORIZONTE + 6, ALTURA - 6)
            self.tufos.append((rng.randint(0, LARGURA), ty, rng.randint(5, 11),
                               0.5 + (ty - HORIZONTE) / 100 * 1.2))

    def _criar_nuvem(self, rng):
        surf = pygame.Surface((240, 60), pygame.SRCALPHA)
        for _ in range(7):
            w, h = rng.randint(70, 130), rng.randint(16, 30)
            pygame.draw.ellipse(surf, (110, 85, 150, 38), (rng.randint(0, 240 - w), rng.randint(8, 60 - h), w, h))
        return surf

    def _criar_neblina(self):
        altura = 70
        surf = pygame.Surface((LARGURA, altura), pygame.SRCALPHA)
        for y in range(altura):
            a = int(70 * (y / altura) ** 1.6)
            pygame.draw.line(surf, (90, 150, 140, a), (0, y), (LARGURA, y))
        return surf

    def _criar_montanhas(self, cor, altura_max, ondas, semente):
        # Perfil baseado em senoides inteiras: repete sem emendas visíveis
        rng = random.Random(semente)
        fases = [rng.random() * 6.28 for _ in ondas]
        surf = pygame.Surface((LARGURA, altura_max + 10), pygame.SRCALPHA)
        pontos = [(0, altura_max + 10)]
        for x in range(0, LARGURA + 1, 8):
            h = 0
            for k, ph in zip(ondas, fases):
                h += math.sin(2 * math.pi * k * x / LARGURA + ph) / len(ondas)
            y = altura_max * 0.55 - h * altura_max * 0.5 + altura_max * 0.2
            pontos.append((x, y))
        pontos.append((LARGURA, altura_max + 10))
        pygame.draw.polygon(surf, cor, pontos)
        return surf

    def desenhar(self, tela):
        self.tempo += 1
        tela.blit(self.ceu, (0, 0))  # Céu escuro em degradê

        # Estrelas cintilando
        agora = pygame.time.get_ticks() * 0.003
        for ex, ey, tam, ph in self.estrelas:
            b = int(150 + 100 * math.sin(agora + ph))
            pygame.draw.circle(tela, (b, b, min(255, b + 20)), (ex, ey), tam)

        # Lua
        brilho(tela, (150, 150, 210), (650, 95), 110, 0.5)
        pygame.draw.circle(tela, (225, 225, 240), (650, 95), 34)
        pygame.draw.circle(tela, (195, 195, 215), (640, 88), 7)
        pygame.draw.circle(tela, (195, 195, 215), (662, 104), 5)
        pygame.draw.circle(tela, (205, 205, 225), (655, 82), 4)

        # Nuvens à deriva
        for nx, ny, vel, surf in self.nuvens:
            px = (nx - self.tempo * vel) % (LARGURA + 240) - 240
            tela.blit(surf, (int(px), ny))

        # Montanhas com parallax (camadas se movem em velocidades diferentes)
        off_longe = int(self.tempo * 0.15) % LARGURA
        off_perto = int(self.tempo * 0.4) % LARGURA
        y_longe = HORIZONTE - self.montanhas_longe.get_height() + 25
        y_perto = HORIZONTE - self.montanhas_perto.get_height() + 12
        for off, surf, yy in ((off_longe, self.montanhas_longe, y_longe),
                              (off_perto, self.montanhas_perto, y_perto)):
            tela.blit(surf, (-off, yy))
            tela.blit(surf, (LARGURA - off, yy))

        # Neblina na base das montanhas
        tela.blit(self.neblina, (0, HORIZONTE - 60))

        # Chão
        tela.blit(self.chao, (0, HORIZONTE))
        pygame.draw.line(tela, (90, 190, 110), (0, HORIZONTE), (LARGURA, HORIZONTE), 3)

        # Piso em perspectiva: linhas horizontais mais espaçadas perto da câmera
        for off in (12, 30, 54, 84):
            pygame.draw.line(tela, (34, 88, 50), (0, HORIZONTE + off), (LARGURA, HORIZONTE + off), 1)
        desloc = (self.tempo * 1.0) % 100
        for i in range(-3, 12):
            xh = i * 100 - desloc
            xb = 400 + (xh - 400) * 1.9
            pygame.draw.line(tela, (30, 80, 46), (xh, HORIZONTE), (xb, ALTURA), 1)

        # Tufos de grama rolando
        for tx, ty, th, tv in self.tufos:
            px = int((tx - self.tempo * tv) % LARGURA)
            pygame.draw.line(tela, (50, 130, 72), (px, ty), (px - 3, ty - th), 2)
            pygame.draw.line(tela, (70, 165, 92), (px, ty), (px, ty - th - 2), 2)
            pygame.draw.line(tela, (50, 130, 72), (px, ty), (px + 3, ty - th), 2)

        # Vagalumes
        t = pygame.time.get_ticks() * 0.001
        for vg in self.vagalumes:
            vx = vg[0] + math.sin(t * vg[3] + vg[2]) * 30
            vy = vg[1] + math.cos(t * vg[3] * 0.8 + vg[2]) * 14
            if math.sin(t * 2 * vg[3] + vg[2]) > -0.3:
                brilho(tela, (190, 255, 120), (vx, vy), 9, 0.8)
                pygame.draw.circle(tela, (240, 255, 200), (int(vx), int(vy)), 1)

# ==========================================
# LOOP PRINCIPAL DO JOGO
# ==========================================
async def main():
    conn = inicializar_db()
    relogio = pygame.time.Clock()

    jogador = Jogador("Jogador1")
    jogador.carregar_progresso(conn)

    fase = EsteticaFase()
    inimigos = []
    projetis = []
    projetis_boss = []
    particulas = []
    textos = []
    tremor = 0   # frames restantes de tremor de tela
    flash = 0    # frames restantes de flash vermelho

    estado_jogo = "JOGANDO" # Pode ser "JOGANDO", "LOJA", "GAMEOVER"
    abates_para_boss = 30
    proximo_boss = calcular_proximo_boss(jogador.abates, abates_para_boss)
    boss_ativo = False

    cursor_mao = False
    rodando = True
    while rodando:
        TELA.fill((0, 0, 0))
        mouse_pos = pygame.mouse.get_pos()
        sobre_clicavel = False

        # 1. TRATAMENTO DE EVENTOS
        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:
                jogador.salvar_progresso(conn)
                rodando = False

            # Mouse: clique esquerdo
            if evento.type == pygame.MOUSEBUTTONDOWN and evento.button == 1:
                if estado_jogo == "JOGANDO":
                    if BOTAO_LOJA.collidepoint(evento.pos):
                        estado_jogo = "LOJA"
                elif estado_jogo == "LOJA":
                    if BOTAO_VOLTAR.collidepoint(evento.pos):
                        estado_jogo = "JOGANDO"
                    else:
                        for i, rect in enumerate(RECT_ITENS):
                            if rect.collidepoint(evento.pos):
                                if comprar(jogador, i):
                                    jogador.salvar_progresso(conn)
                elif estado_jogo == "GAMEOVER" and BOTAO_RESTART.collidepoint(evento.pos):
                    reiniciar_partida(jogador, inimigos, projetis, projetis_boss, particulas, textos)
                    boss_ativo = False
                    tremor = 0
                    flash = 0
                    estado_jogo = "JOGANDO"

        if estado_jogo == "JOGANDO":
            fase.desenhar(TELA)

            # Spawn de inimigos (escalonados em x para não nascerem empilhados)
            if len(inimigos) == 0:
                if jogador.abates >= proximo_boss and not boss_ativo:
                    inimigos.append(Boss(100 + (jogador.abates * 2), 100))
                    boss_ativo = True
                else:
                    boss_ativo = False
                    for i in range(random.randint(1, 3)):
                        inimigos.append(Inimigo(30 + (jogador.abates), 10, deslocamento_x=i * 70))

            # Ataque Automático do Jogador
            jogador.timer_ataque += 1
            if jogador.timer_ataque >= jogador.cooldown_ataque and len(inimigos) > 0:
                projetis.append(Projetil(jogador.x + 40, jogador.y, jogador.ataque_base))
                jogador.timer_ataque = 0
                jogador.recuo = 5
                for _ in range(5):
                    particulas.append(Particula(jogador.x + 50, jogador.y + 20, (255, 210, 90),
                                                vx=random.uniform(1, 4), vy=random.uniform(-1.5, 1.5),
                                                vida=random.randint(8, 14), tam=2.5))

            # Tiro automático do boss
            for inimigo in inimigos:
                if isinstance(inimigo, Boss) and inimigo.vivo:
                    inimigo.timer_tiro += 1
                    if inimigo.timer_tiro >= inimigo.INTERVALO_TIRO:
                        projetis_boss.append(ProjetilBoss(
                            inimigo.x, inimigo.y + inimigo.ALTURA_CORPO / 2, inimigo.DANO_TIRO
                        ))
                        inimigo.timer_tiro = 0

            # Atualizar e verificar os tiros do boss
            for projetil in projetis_boss[:]:
                projetil.atualizar()
                if not projetil.ativo:
                    projetis_boss.remove(projetil)
                    continue
                projetil.desenhar(TELA)
                if (jogador.x <= projetil.x <= jogador.x + jogador.LARGURA_CORPO
                        and jogador.y <= projetil.y <= jogador.y + jogador.ALTURA_CORPO):
                    jogador.receber_dano(projetil.dano)
                    projetil.ativo = False
                    projetis_boss.remove(projetil)
                    tremor = 12
                    flash = 10
                    textos.append(TextoFlutuante(
                        f"-{projetil.dano}", (255, 90, 90), jogador.x + 20, jogador.y - 34
                    ))

            # Atualizar e Desenhar Projéteis
            for p in projetis[:]:
                p.atualizar()
                if not p.ativo:
                    projetis.remove(p)
                    continue
                p.desenhar(TELA)

            # Atualizar e Desenhar Inimigos
            for inimigo in inimigos[:]:
                inimigo.atualizar()
                inimigo.desenhar(TELA)

                # Colisão Projétil -> Inimigo
                for p in projetis:
                    if p.ativo and inimigo.x < p.x < inimigo.x + inimigo.LARGURA_CORPO + 10:
                        inimigo.receber_dano(p.dano)
                        p.ativo = False
                        for _ in range(6):
                            particulas.append(Particula(p.x, p.y, (255, 200, 80), vx=random.uniform(-4, 1),
                                                        vy=random.uniform(-3, 2), vida=random.randint(10, 20), tam=3))
                        textos.append(TextoFlutuante(str(p.dano), (255, 235, 140), inimigo.x + inimigo.LARGURA_CORPO / 2,
                                                     inimigo.y - 26))

                # Colisão Inimigo -> Jogador
                if inimigo.vivo and inimigo.x <= jogador.x + 40:
                    dano_colisao = inimigo.DANO_COLISAO if isinstance(inimigo, Boss) else 10
                    jogador.receber_dano(dano_colisao)
                    inimigo.vivo = False # Monstro explode ao bater no jogador
                    tremor = 12
                    flash = 10
                    textos.append(TextoFlutuante(
                        f"-{dano_colisao}", (255, 90, 90), jogador.x + 20, jogador.y - 34
                    ))

                if not inimigo.vivo:
                    inimigos.remove(inimigo)
                    jogador.abates += 1
                    jogador.dinheiro += inimigo.recompensa
                    jogador.salvar_progresso(conn)
                    cx = inimigo.x + inimigo.LARGURA_CORPO / 2
                    cy = inimigo.y + inimigo.ALTURA_CORPO / 2
                    qtd = 40 if isinstance(inimigo, Boss) else 14
                    for _ in range(qtd):
                        particulas.append(Particula(cx, cy, inimigo.cor))
                    for _ in range(qtd // 2):
                        particulas.append(Particula(cx, cy, (255, 215, 70)))
                    textos.append(TextoFlutuante(f"+{inimigo.recompensa}", (255, 215, 60), cx, inimigo.y - 24))
                    if isinstance(inimigo, Boss):
                        proximo_boss += abates_para_boss
                        tremor = 20

            if not any(isinstance(inimigo, Boss) and inimigo.vivo for inimigo in inimigos):
                projetis_boss.clear()

            jogador.desenhar(TELA)

            # Partículas e textos
            for pt in particulas[:]:
                pt.atualizar()
                if pt.vida <= 0 or pt.y > ALTURA:
                    particulas.remove(pt)
                else:
                    pt.desenhar(TELA)
            for tx in textos[:]:
                tx.atualizar()
                if tx.vida <= 0:
                    textos.remove(tx)
                else:
                    tx.desenhar(TELA)

            if not jogador.vivo:
                estado_jogo = "GAMEOVER"
                jogador.salvar_progresso(conn)

            # Tremor de tela
            if tremor > 0:
                copia = TELA.copy()
                TELA.fill((0, 0, 0))
                amp = 1 + tremor // 4
                TELA.blit(copia, (random.randint(-amp, amp), random.randint(-amp, amp)))
                tremor -= 1

            # Vinheta para dar clima
            TELA.blit(VINHETA, (0, 0))

            # Flash vermelho ao levar dano
            if flash > 0:
                FLASH_DANO.set_alpha(flash * 8)
                TELA.blit(FLASH_DANO, (0, 0))
                flash -= 1

            # HUD
            painel(TELA, (10, 10, 380, 92))
            pygame.draw.circle(TELA, (255, 200, 40), (28, 28), 8)
            pygame.draw.circle(TELA, (255, 240, 130), (26, 26), 3)
            texto_sombra(TELA, FONTE, f"Ouro: {jogador.dinheiro}", (255, 255, 255), (44, 17))
            texto_sombra(TELA, FONTE, f"Abates: {jogador.abates}", (255, 255, 255), (230, 17))

            barra(TELA, 20, 46, 250, 14, jogador.vida / jogador.vida_max, (60, 220, 90))
            hp_txt = FONTE_PEQ.render(f"HP {jogador.vida}/{jogador.vida_max}", True, (255, 255, 255))
            TELA.blit(hp_txt, (278, 47))

            if boss_ativo and any(isinstance(i, Boss) for i in inimigos):
                boss_txt = FONTE_PEQ.render("BOSS!", True, (230, 150, 255))
                barra(TELA, 20, 68, 250, 8, 1, (200, 60, 255), fundo=(40, 10, 50))
            else:
                faltam = max(0, proximo_boss - jogador.abates)
                progresso = 1 - faltam / abates_para_boss
                boss_txt = FONTE_PEQ.render(f"Boss em {faltam}", True, (200, 170, 230))
                barra(TELA, 20, 68, 250, 8, progresso, (170, 80, 230), fundo=(40, 10, 50))
            TELA.blit(boss_txt, (278, 66))

            # Botão clicável da loja
            sobre_clicavel = botao(TELA, BOTAO_LOJA, "Loja", mouse_pos)

        elif estado_jogo == "LOJA":
            TELA.blit(FUNDO_LOJA, (0, 0))
            painel(TELA, (55, 20, 690, 560), cor=(10, 10, 30), alpha=190, borda=(90, 90, 150))
            texto_sombra(TELA, FONTE_TITULO, "LOJA", (255, 215, 0), (0, 38), centro_x=True)
            ouro_txt = FONTE.render(f"OURO: {jogador.dinheiro}", True, (255, 255, 255))
            TELA.blit(ouro_txt, ouro_txt.get_rect(center=(LARGURA // 2, 100)))

            itens = [
                ("ATAQUE", jogador.nivel_ataque, (255, 100, 100)),
                ("VELOCIDADE DE ATAQUE", jogador.nivel_vel_ataque, (100, 255, 100)),
                ("VIDA MÁXIMA", jogador.nivel_vida, (100, 150, 255)),
            ]
            for (nome, nivel, cor), rect in zip(itens, RECT_ITENS):
                custo = nivel * 50
                pode = jogador.dinheiro >= custo
                sobre = rect.collidepoint(mouse_pos)
                if sobre:
                    sobre_clicavel = True
                borda = cor if pode else (80, 80, 100)
                painel(TELA, tuple(rect), cor=(35, 35, 80) if sobre else (15, 15, 40),
                       alpha=225 if sobre else 190,
                       borda=(255, 255, 255) if (sobre and pode) else borda)
                pygame.draw.rect(TELA, cor, (rect.x + 18, rect.y + 17, 6, 42))
                TELA.blit(FONTE.render(nome, True, cor), (rect.x + 38, rect.y + 8))
                detalhe = FONTE_PEQ.render(f"NIVEL {nivel}   |   CUSTO {custo} OURO", True, (210, 210, 235))
                TELA.blit(detalhe, (rect.x + 38, rect.y + 42))

                botao_rect = pygame.Rect(rect.right - 158, rect.y + 15, 140, 46)
                cor_botao = cor if pode else (80, 80, 100)
                pygame.draw.rect(TELA, (25, 25, 55), botao_rect)
                pygame.draw.rect(TELA, cor_botao, botao_rect, 2)
                acao = FONTE_PEQ.render("COMPRAR" if pode else "SEM OURO", True, cor_botao)
                TELA.blit(acao, acao.get_rect(center=botao_rect.center))

            ajuda = FONTE_PEQ.render("CLIQUE EM UMA MELHORIA PARA COMPRAR", True, (180, 180, 205))
            TELA.blit(ajuda, ajuda.get_rect(center=(LARGURA // 2, 414)))
            painel(TELA, (100, 438, 600, 60), cor=(15, 15, 40), alpha=160, borda=(90, 90, 150))
            tiros = FPS / jogador.cooldown_ataque
            stats = f"Dano: {jogador.ataque_base}   |   Tiros/s: {tiros:.1f}   |   Vida máx: {jogador.vida_max}"
            stats_txt = FONTE.render(stats, True, (210, 210, 235))
            TELA.blit(stats_txt, stats_txt.get_rect(center=(LARGURA // 2, 468)))

            if botao(TELA, BOTAO_VOLTAR, "Voltar à Batalha", mouse_pos):
                sobre_clicavel = True

        elif estado_jogo == "GAMEOVER":
            TELA.blit(FUNDO_GAMEOVER, (0, 0))
            TELA.blit(VINHETA, (0, 0))
            painel(TELA, (200, 215, 400, 230), cor=(30, 0, 0), alpha=190, borda=(255, 90, 90), raio=14)
            texto_sombra(TELA, FONTE_TITULO, "GAME OVER", (255, 255, 255), (300, 235), centro_x=True)
            texto_sombra(TELA, FONTE, f"Abates Finais: {jogador.abates}", (255, 220, 220), (320, 300), centro_x=True)
            if botao(TELA, BOTAO_RESTART, "REINICIAR", mouse_pos, cor=(100, 255, 140)):
                sobre_clicavel = True

        if sobre_clicavel != cursor_mao:
            cursor_mao = sobre_clicavel
            try:
                pygame.mouse.set_cursor(pygame.SYSTEM_CURSOR_HAND if cursor_mao else pygame.SYSTEM_CURSOR_ARROW)
            except Exception:
                pass

        pygame.display.flip()
        relogio.tick(FPS)
        await asyncio.sleep(0)

    pygame.quit()
    if sys.platform != "emscripten":
        conn.close()

if __name__ == "__main__":
    asyncio.run(main())